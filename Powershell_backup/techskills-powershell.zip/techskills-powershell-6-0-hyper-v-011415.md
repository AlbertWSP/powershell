Powershell for System Admins
============================================================

Hyper-V
------------------------------------------------------------

* These commands are new to PowerShell v3.0
* Prior to 3.0 there were no PowerShell cmdlets for Hyper-V
* Prior to 3.0 you could use the SCVMM modules to control
  Hyper-V if you had SCVMM.
	+ http://technet.microsoft.com/en-us/library/hh848559.aspx
* Installing Hyper-V
  + `Install-WindowsFeature -Name Hyper-V -IncludeManagementTools -Restart`
* Verify Install
  + `Get-Service vmms`
  + `Get-VMHost`
  + `Get-VM`
* Working with Virtual Machines (VM)
  + Creating a VM
    - Create a VM with 2GB of RAM and a 64GB Dynamically
      Expanding Disk
      + `New-VM -Name "WEBSERVER01" -MemoryStartupBytes 2048MB -SwitchName "Local Area Network" -NewVHDPath "C:\VM\WEBSERVER01-Disk1.vhdx" -NewVHDSizeBytes 64GB`
  + Modifying a VM
    - Adjust # of CPUs
      + `Set-VMProcessor "WEBSERVER01" -Count 2`
    - Enable/Disable Dynamic Memory
      + `Set-VMMemory "WEBSERVER01" -DynamicMemoryEnabled $true`
  + Start/Stop VMs
    - `Start-VM "WEBSERVER01"`
    - `Stop-VM "WEBSERVER01"`
    - `Start-VM *`
  + Delete a VM
    - `Remove-VM "WEBSERVER01"`
* Working with Virtual Hard Drives (VHD)
  + Creating VHDs
    - Create a Dynamic VHD
      + `New-VHD -Path "C:\VM\WEBSERVER01-Disk2.vhdx" -SizeBytes 36GB`
    - Create a Fixed Size VHD
      + `New-VHD -Path "C:\VM\WEBSERVER01-Disk3.vhdx" -Fixed -SizeBytes 36GB`
    - Create a Differencing Disk
      + `New-VHD -ParentPath "C:\VM\WEBSERVER01-Disk1.vhdx" -Path "C:\VM\WEBSERVER02-Disk1.vhdx" -Differencing`
  + Attach an Existing VHD to a VM
    `-Add-VMHardDiskDrive -VMName "WEBSERVER01" -Path "C:\VM\WEBSERVER01-Disk2.vhdx"`
    `-Add-VMHardDiskDrive -VMName "WEBSERVER01" -Path "C:\VM\WEBSERVER01-Disk3.vhdx"`
* Working with Virtual Switches (vSwitch)
  + List Virtual Switches
    - `Get-VMSwitch`
  + Create a Private Network
    - `New-VMSwitch "Private LAN" -SwitchType Private -Notes "This is an isolated network"``
  + Create an External (Public) Network
    - Find the Adapter Name
      + `Get-NetAdapter -Name * | Format-List`
    - Create the Switch
      + `New-VMSwitch -Name "Local Area Network" -NetAdapterName "Local Area Connection" -AllowManagementOS $true`
  + Attach a VM to a Virtual Switch
    - `Add-VMNetworkAdapter -VMName "WEBSERVER01" -SwitchName "Private LAN"`
* Working with VM Snapshots
  + Create a Snapshot on a VM
    - `Checkpoint-VM -Name WEBSERVER01 -SnapshotName "Prior to Update"`
  + List Snapshots
    - `Get-VMSnapshot –VMName WEBSERVER01`
  + Apply/Rollback to a Snapshot
    - `Restore-VMSnapshot –Name 'Prior to Update' –VMName WEBSERVER01`
* Importing / Exporting VMs
	+ `Export-VM –Name ITProTV-DC2 –Path C:\Exported`
	+ `Import-VM -Path C:\Exported\ITPROTV-DC2\Virtual Machine\2F87C74EF5C6-4463BE35-7B6464D9E525.XML -Copy`
	+ If there are errors during import
		- `$Report = Compare-VM -Path C:\Exported\ITPROTV-DC2\Virtual Machine\2F87C74EF5C6-4463BE35-7B6464D9E525.XML -copy`
		- `$report.Incompatibilities | Format-Table -AutoSize` 
		