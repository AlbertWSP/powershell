Powershell for System Admins
============================================================
3.1 Installing DNS
3.2 Managing Zones
3.3 Managing DNS Records
3.4 Monitoring DNS Status

DNS
------------------------------------------------------------

* Installing DNS
  - `Install-WindowsFeature DNS`
  - `Install-WindowsFeature DNS –IncludeManagementTools`
* Configuring Zones
  + Create a primary zone
    - `Add-DnsServerPrimaryZone -Name "west01.contoso.com" -ReplicationScope "Forest" -PassThru`
  + Create a file-backed primary zone
    - `Add-DnsServerPrimaryZone -Name "west02.contoso.com" -ZoneFile "west02.contoso.com.dns"`
  + Create a reverse lookup zone
    - `Add-DnsServerPrimaryZone -NetworkID "10.1.0.0/24" -ReplicationScope "Forest"`
  + Create a file-backed reverse lookup zone
    - `Add-DnsServerPrimaryZone -NetworkID 10.3.0.0/24 -ZoneFile "0.3.10.in-addr.arpa.dns"`
  + Add a secondary DNS server zone
    - `Add-DnsServerSecondaryZone -Name "west01.contoso.com" -ZoneFile "western.contoso.com.dns"
      -MasterServers 172.23.90.124 `
  + Allow zone transfers
    - `Set-DnsServerPrimaryZone -Name west01.contoso.com -notify notify
        -SecondaryServers 192.168.1.103 -SecureSecondaries TransferToSecureServers`
* Adding Resourse Records
  + Add an A record
    - `Add-DnsServerResourceRecord -ZoneName "Contoso.com" -A -Name "Host34"
        -AllowUpdateAny -IPv4Address "10.17.1.34" -TimeToLive 01:00:00 -AgeRecord`
  + Add an AAAA resource record
    - `Add-DnsServerResourceRecord -AAAA -Name "Host73" -ZoneName "Contoso.com"
        -AllowUpdateAny -IPv6Address "3ffe::1" -TimeToLive 01:00:00 -AgeRecord`
  + Add a CNAME resource record
    - `Add-DnsServerResourceRecord -CName -Name "labhost34" -HostNameAlias "Host34.lab.contoso.com"
        -ZoneName "Contoso.com" -AllowUpdateAny  -TimeToLive 01:00:00`
  + Add a PTR resource record
    - `Add-DnsServerResourceRecord -Name "77" -Ptr -ZoneName "0.168.192.in-addr.arpa"
        -AllowUpdateAny -PtrDomainName "host77.contoso.com"`
  + Add an MX resource record
    - `Add-DnsServerResourceRecord -Name ".-MX -ZoneName "contoso.com"
        –MailExchange "mail.contoso.com" -Preference 10`
  + Add an SRV resource record
    - `Add-DnsServerResourceRecord -Srv -Name "sip" -ZoneName "contoso.com"
        –DomainName "sipserver1.contoso.com" –Priority 0 –Weight 0 –Port 5060`
* Monitoring Status
  + Get server configuration
    - `Get-DnsServer`
  + Get server statistics for the local DNS server
    - `Get-DnsServerStatistics`
  + Get server statistics for a specific zone
    - `Get-DnsServerStatistics -ZoneName contoso.com`
  + Clear statistics for a specific zone
    - `Get-DnsServerStatistics -ZoneName contoso.com -Clear`
