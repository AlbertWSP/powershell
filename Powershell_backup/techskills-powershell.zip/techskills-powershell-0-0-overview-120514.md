Powershell for System Admins
============================================================

Outline
------------------------------------------------------------

* Introduction to PowerShell
	+ Basic Command Syntax
	+ Help Commands
	+ Piping Command Output
	+ Formating Command Output
	+ Script Execution Policies
	+ Customizing the interface
	+ Extending the PowerShell with additional cmdlets
	+ Local vs Remote Management
	+ PowerShell ISE
	+ PowerShell Drives
* Server Management
	+ Add/Remove Roles and Features
	+ Working with Disks
	+ Registry Operations
	+ Configuring Networking
	+ Configuring Windows Firewall
	+ Managing Services
	+ Managing Processes
	+ Add/Modify Printers
	+ File Operations
* DNS
	+ Installing DNS
	+ Configuring Zones
	+ Monitoring Status
* DHCP
	+ Installing DHCP
	+ Configuring Scopes
	+ Monitoring Status
* Active Directory Domain Services
	+ Installing AD:DS Role
	+ Promoting a DC
	+ Create/Modify/Delete User Accounts
	+ Create/Modify/Delete Groups
	+ Create/Modify/Delete OU Structures
	+ Import/Export Data
	+ Performing Bulk Operations
* Hyper-V
	+ Installing Hyper-V
	+ Host Administration
	+ Virtual Networking
	+ Create/Modify/Delete VMs
	+ VM Administration
	+ Create/List/Restore Checkpoints
