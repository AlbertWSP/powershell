Powershell for System Admins
============================================================

DHCP
------------------------------------------------------------

* Installing DHCP
  + `Install-WindowsFeature -Name 'DHCP'`
  + `Install-WindowsFeature -Name 'DHCP' –IncludeManagementTools`
* Authorize server
  + List authorized servers
    - `Get-DhcpServerInDC`
  + Authorize a server
    - `Add-DhcpServerInDC -DnsName server1.domain.com -IPAddress 192.168.0.2`
  + De-Authorize a server
    - `Remove-DhcpServerInDC -DnsName server1.domain.com -IPAddress 192.168.0.2`
* Create a Scope
  + `Add-DhcpServerv4Scope -Name 'ITProTV Studio' -StartRange 10.1.230.100 -EndRange 10.1.230.150 -SubnetMask 255.255.255.0`
  + Add `-ComputerName <Name>` to point to the DHCP server
    if commands are being executed remotely
* Delete a scope
  + `Remove-DhcpServerv4Scope -ScopeId 10.1.230.0`
* Configuring scope options
  + `Set-DhcpServerv4OptionValue -ScopeId 10.1.230.0 -DnsServer 10.1.230.11 -DnsDomain studio.itpro.tv -Router 10.1.230.1`
  + More examples available on [TechNet][1]
* Enable/disable scope
  + `Set-DhcpServerv4Scope -ScopeId 10.1.230.0 -State <Active/Inactive>`
* Create scope exclusions
  + `Add-Dhcpserverv4ExclusionRange -ScopeId 10.1.230.0 -StartRange 10.1.230.105 -EndRange 10.1.230.110`
* Create reservations
  + `Add-DhcpServerv4Reservation -ScopeId 10.1.230.0 -IPAddress 10.1.230.222 -ClientId 00-e0-1b-6f-f3-10 -Name DonLaptop`
  + Use Get/Remove to modify
* Monitoring Status
  + List Scopes
    - `Get-DhcpServerv4Scope`
  + List Leases
    - `Get-DhcpServerv4Lease -AllLeases -ScopeId 10.1.230.0`
  + Scope usage
    - `Get-DhcpServerv4ScopeStatistics -ScopeId 10.1.230.0`

[1]:http://technet.microsoft.com/en-us/library/jj590669.aspx
