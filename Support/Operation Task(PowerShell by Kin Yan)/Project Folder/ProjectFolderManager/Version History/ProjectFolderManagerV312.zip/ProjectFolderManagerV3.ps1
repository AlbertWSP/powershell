###
#Requirement:
#1) PowerShell 5.x(not compatible with PS7.x);
#2) RSAT-AD-PowerShell feature installed;

#Initial Setup:
#1. Copy this shell and the XML profile to--->"C:\Support\ProjectFolderManager"
#1. Enable PS: Set-ExecutionPolicy RemoteSigned
#2. Install RSAT-AD-PowerShell feature: Install-WindowsFeature RSAT-AD-PowerShell

#Author: Kin.Yan@wsp.com
#Description: This is the most powerful tool for project folder management in the planet, i'm not joking, you can feel how powerful it is.......from the window title :)

#What's new in V3.12(2022/1/11):
#1. In this version, there is a new Action----"SetFolderOwner"
#2. Add shell version and profile version in the report

#What's new in V3(2021/11/15):
#1. Not use NTFSSecurity module anymore, use pure Powershell
#2. 'CreateFolder', 'GrantFolderPermission', 'CreateADGroup' now support define multiple targets in one line by adding a separator "|"
#3. Add parameter 'Inheritance' & 'PermissionType' to 'GrantFolderPermission' action so that you can control permission apply to this folder only or subfolders, and grant "Allow" or "Deny" permission.
#4. Create "Report" folder automatically if the folder is not exist
#5. Show success and fail task count in report and prompt window after tasks completed
#one more thing......bug fixed!!!
###

$FormTitle="Project Folder Manager Pro Plus Ultimate V3"
$ShellVersion=3.12
$PowershellPath = "C:\Support\ProjectFolderManager"
$ProfilePath = Join-Path $PowershellPath "ProjectFoldersV3.xml"
if((Test-Path $ProfilePath) -eq $True)
{
    $global:xmldata = New-Object -TypeName XML
    $global:xmldata.Load($ProfilePath)

    $ProfileVersion=$xmldata.Offices.Attributes["ProfileVersion"].Value

}
else {
    write-host ("XML Profile not found![" + $ProfilePath + "]")
    Exit
}

$global:exitcode = 1
$global:RootFolder=""
$global:PermissionPrefix=""
$script:SuccessTaskCount = 0
$script:FailTaskCount = 0
# success=1, fail=9

########################################Action Start##########################################
function CreateADGroup
{
    Param(  [string] $GroupName,
	        [string] $GroupScope,
            [string] $Description,
            [string] $OUPath)
    
    #GroupScope: Universal, Global, Domain Local
    $Groups=$GroupName.Split("|")
    foreach($Group in $Groups)
    {
        $resultprefix=""
        try {
            New-ADGroup -name $Group -GroupScope $GroupScope -Description $Description -path $OUPath -ErrorAction Stop
            $resultprefix="[Success] "
            $script:SuccessTaskCount=$script:SuccessTaskCount+1
            $global:exitcode=1
            #return $False
        }
        catch
        {
            #$resultprefix="[Fail: " + $Error.Exception + "] "
            $resultprefix="[Fail] "
            $script:FailTaskCount=$script:FailTaskCount+1
            $exitcode=9
            #return $true
        }

        $R=$resultprefix + "<Create AD group:> " + $Group
        if($ResultList)
        {
            $ResultList.Items.Add($R)
        }
        else {
            write-host ($R)
        }
    }
}

function CreateFolder
{
    Param([string] $FolderPath,
          [string] $FolderName
    )

    $Folders=$FolderName.Split("|")
    foreach($folder in $Folders)
    {
        $resultprefix=""
        try {
            $fullpath=Join-Path $FolderPath $folder
            New-Item -Path $fullpath -ItemType Directory -ErrorAction Stop
            $resultprefix="[Success] "
            $script:SuccessTaskCount=$script:SuccessTaskCount+1
            $global:exitcode=1
            #return $True
            }
        catch
        {
            $resultprefix="[Fail] "
            $script:FailTaskCount=$script:FailTaskCount+1
            $exitcode=9
            #return $False
        }

        $R=$resultprefix + "<Create folder:> " + $fullpath
        if($ResultList)
        {
            $ResultList.Items.Add($R)
        }
        else {
            write-host ($R)
        }
    }    
}

function AddADGroupMember
{
    Param([string] $ADGroupName,
          [string] $Member
    )
    $resultprefix=""    
    try {
        #Add-ADGroupMember $ADGroupName -Members $Member -ErrorAction Stop
        Get-ADGroup $ADGroupName | Add-ADGroupMember -Members $Member -ErrorAction Stop
        $resultprefix="[Success] "
        $script:SuccessTaskCount=$script:SuccessTaskCount+1
        $global:exitcode=1
        #return $True
        }
    catch
    {
        $resultprefix="[Fail] "
        $script:FailTaskCount=$script:FailTaskCount+1
        $exitcode=9
        #return $False
    }

    $R=$resultprefix + "<Add AD group member: Member:> " + $Member + "; <ADGroup:> " + $ADGroupName
    if($ResultList)
    {
        $ResultList.Items.Add($R)
    }
    else {
        write-host ($R)
    }
}

function GrantFolderPermission
{
    Param([string] $FolderPath,
          [string] $UserOrGroups,
          [string] $Permission,
          [string] $Inheritance,
          [string] $IsNew,
          [string] $PermissionType
    )
    #Permission set in PowerShell: ReadAndExecute, FullControl, Modify, Write, Read, CreateFiles, CreateDirectories, Delete
    #Reference: https://docs.microsoft.com/en-us/dotnet/api/system.security.accesscontrol.filesystemrights?view=windowsdesktop-5.0
    #$Inheritance: ThisFolderOnly, ThisAndSubFolders, ThisAndSubFoldersAndFiles
    #$PermissionType: Allow, Deny
    $Identities=$UserOrGroups.Split("|")
    foreach($Identity in $Identities)
    {
        $resultprefix=""
        if((Test-Path $FolderPath) -eq $True)
        {
            try {
                $CurrentAcl = Get-Acl $FolderPath
                if($Inheritance -eq "ThisFolderOnly")
                {
                    #$Identity,$Permission,'ContainerInherit, ObjectInherit','None','InheritOnly',$PermissionType:=====>permission apply to "This folder, subfolders and files"
                    #$NewAcl = New-Object System.Security.AccessControl.FileSystemAccessRule($Identity,$Permission,'None','InheritOnly',$PermissionType)
                    $InheritanceFlag='None'
                    $PropagationFlag='InheritOnly'
                }
                elseif($Inheritance -eq "ThisAndSubFolders")
                {
                    #$NewAcl = New-Object System.Security.AccessControl.FileSystemAccessRule($Identity,$Permission,'ContainerInherit','NoPropagateInherit',$PermissionType)
                    $InheritanceFlag='ContainerInherit'
                    $PropagationFlag='NoPropagateInherit'
                }
                elseif($Inheritance -eq "ThisAndSubFoldersAndFiles")
                {   #'NoPropagateInherit'
                    #$NewAcl = New-Object System.Security.AccessControl.FileSystemAccessRule($Identity,$Permission,'ContainerInherit, ObjectInherit','None',$PermissionType)
                    $InheritanceFlag='ContainerInherit, ObjectInherit'
                    $PropagationFlag='None'
                }

                $NewAcl = New-Object System.Security.AccessControl.FileSystemAccessRule($Identity,$Permission,$InheritanceFlag,$PropagationFlag,$PermissionType)
                if($IsNew -eq "Yes")
                {
                    $CurrentAcl.SetAccessRule($NewAcl)
                }
                else { #Same ID different permission
                    $CurrentAcl.AddAccessRule($NewAcl)
                }
                $CurrentAcl | Set-Acl $FolderPath -ErrorAction Stop
                $resultprefix="[Success] "
                $script:SuccessTaskCount=$script:SuccessTaskCount+1
                $global:exitcode=1
                #return $True
            }
            catch
            {
                $resultprefix="[Fail] "
                $script:FailTaskCount=$script:FailTaskCount+1
                $exitcode=9
                #return $False
            }
        }
        else
        {
            $resultprefix="[Fail] "
            $script:FailTaskCount=$script:FailTaskCount+1
            $exitcode=9
            #return $False
        }

        $R=$resultprefix + "<Grant folder permission: Folder:> " + $FolderPath + "; <Identity:> " + $Identity + "; <Permission:> " + $Permission + "; <Inheritance:> " + $Inheritance + "; <Type:> " + $PermissionType

        if($ResultList)
        {
            $ResultList.Items.Add($R)
        }
        else {
            write-host ($R)
        }
    }
}

function RemoveFolderPermissions
{
    Param([string] $FolderPath,
          [string] $UserOrGroups
    )


    $Identities=$UserOrGroups.Split("|")
    foreach($Identity in $Identities)
    {
        $resultprefix=""
        if((Test-Path $FolderPath) -eq $True)
        {
            try {
                    $CurrentAcl = Get-Acl $FolderPath
                    foreach ($access in $CurrentAcl.Access) 
                    {
                        $accessvalue=$access.IdentityReference.Value.split("\")
                        $Identity2=$Identity.Split("\")
                        if($Identity2 -eq $accessvalue[$accessvalue.length-1])
                        {
                            if($access.IsInherited -eq $True)
                            {
                                $CurrentAcl.SetAccessRuleProtection($True, $True)
                                (Get-Item $FolderPath).SetAccessControl($CurrentAcl)
                                
                                $CurrentAcl = Get-Acl $FolderPath
                            }
                            $AccessRule=New-Object System.Security.AccessControl.FileSystemAccessRule($Identity,"FullControl","Allow")
                            $CurrentAcl.RemoveAccessRule($AccessRule)
                            (Get-Item $FolderPath).SetAccessControl($CurrentAcl)

                            $SID=New-Object System.Security.Principal.NTAccount($Identity)
                            $CurrentAcl.PurgeAccessRules($SID)
                            (Get-Item $FolderPath).SetAccessControl($CurrentAcl)
                        }
                    }
                    $resultprefix="[Success] "
                    $script:SuccessTaskCount=$script:SuccessTaskCount+1
                    $global:exitcode=1
                    #return $True
                    }
            catch{
                    $resultprefix="[Fail] "
                    $script:FailTaskCount=$script:FailTaskCount+1
                    $exitcode=9
                    #return $False
                }
        }
        else
        {
            $resultprefix="[Fail] "
            $script:FailTaskCount=$script:FailTaskCount+1
            $exitcode=9
            #return $False    
        }

        $R=$resultprefix + "<Remove folder permission: Folder:> " + $FolderPath + "; <Identity:> " + $Identity
        if($ResultList)
        {
            $ResultList.Items.Add($R)
        }
        else {
            write-host ($R)
        }
    }
}

function SetFolderOwner
{
    Param([string] $RootFolderPath,
          [string] $Folders,
          [string] $FolderOwner
    )
    #$folderowner=(get-acl $folder).Owner

    $SubFolders=$Folders.Split("|")
    foreach($SubFolder in $SubFolders)
    {
        try {
            $TargetFolder = Join-Path $RootFolderPath $SubFolder
            $acl = Get-Acl $TargetFolder
            $object = New-Object System.Security.Principal.Ntaccount($FolderOwner)
            $acl.SetOwner($object)
            $acl | set-acl $TargetFolder

            $resultprefix="[Success] "
            $script:SuccessTaskCount=$script:SuccessTaskCount+1
            $global:exitcode=1
        }
        catch {
            $resultprefix="[Fail] "
            $script:FailTaskCount=$script:FailTaskCount+1
            $exitcode=9
        }

        $R=$resultprefix + "<Set Folder Owner: Folder:> " + $TargetFolder + "; <Owner:> " + $FolderOwner
        if($ResultList)
        {
            $ResultList.Items.Add($R)
        }
        else {
            write-host ($R)
        }
    }    
}


function GenerateReport{
    Param([string] $ReportType
    )

    $today=Get-Date -Format "yyyyMMddHHmmss"
    $ReportPath= Join-Path $PowershellPath "Report"
    if((Test-Path $ReportPath) -ne $True)
    {
        New-Item -Path $ReportPath -ItemType Directory -ErrorAction Stop
    }
    $reportname=$ReportPath + "\PFMResult_" + $today + ".log"

    $R=""
    for($j=$ResultList.Items.Count-1;$j -gt -1; $j--)
    {
        $R=$ResultList.Items[$j] + "`r`n" + $R
    
    }
    $ReportHeader="PFM Shell Version: " + $ShellVersion + "`r`n"
    $ReportHeader= $ReportHeader + "Profile Version: " + $ProfileVersion + "`r`n"
    $ReportHeader= $ReportHeader + "Host Name: " + $env:COMPUTERNAME + "`r`n"
    $ReportHeader= $ReportHeader + "Executed By: " + $env:UserName + "`r`n"
    $ReportHeader= $ReportHeader + "Office: " + $OfficeList.SelectedItem.ToString() + "`r`n" 
    $ReportHeader= $ReportHeader + "Team: " + $TeamList.SelectedItem.ToString() + "`r`n"
    $ReportHeader= $ReportHeader + "Date/Time: " + $today.Substring(0,4) + "/" + $today.Substring(4,2) + "/" + $today.Substring(6,2) + " " + $today.Substring(8,2) + ":"+ $today.Substring(10,2) + ":" + $today.Substring(12,2) + "`r`n"
    $ReportHeader= $ReportHeader + "Project No.: " + $ProjectNumber.Text + "`r`n"
    $ReportHeader= $ReportHeader + "Project Name: " + $ProjectName.Text + "`r`n"
    $ReportHeader= $ReportHeader + "Description: " + $ProjectDescription.Text + "`r`n"
    $ReportHeader= $ReportHeader + "Tasks(Success:" + $script:SuccessTaskCount + " ; Fail:" + $script:FailTaskCount + "): " + "`r`n"

    
    $R=$ReportHeader + $R + "*********Report End*********"
    #Write-Host "Selected File and Location:"  -ForegroundColor Green
    if($ReportType -eq "Clipboard")
    {
        $R | Set-Clipboard
        [System.Windows.Forms.Messagebox]::Show("Result copied to clipboard")
    }
    else {
        $R | Out-File -FilePath $reportname        
    }

}

##############################Action End################################################
function getTeamNode()
{
    Param(  [string] $aoffice,
            [string] $ateam
    )
    $xp="//Office[@Name='" + $aoffice + "']/Team[@Name='" + $ateam + "']"
    $node=$global:xmldata | Select-Xml -XPath $xp
    return $node
}

function ExecuteActions()
{
    Param(  [string] $aoffice,
            [string] $ateam,
            [string] $aprojectnumber,
            [string] $aprojectname,
            [string] $aprojectdescription
    )

    $node=getTeamNode -aoffice $aoffice -ateam $ateam
    $global:RootFolder=$node.Node.Attributes["RootFolder"].Value
    for($i=0;$i -lt $node.Node.ChildNodes.Count; $i++)
    {
        Switch($node.Node.ChildNodes[$i].Attributes["Type"].Value)
        {
            'CreateADGroup' {
                                $adpath=$node.Node.ChildNodes[$i].Attributes["OU"].Value
                                $adgroupname=$node.Node.ChildNodes[$i].InnerText
				                $adgroupname=$adgroupname.Replace("{ProjectNumber}",$aprojectnumber)
                                $adgroupscope=$node.Node.ChildNodes[$i].Attributes["Scope"].Value
                                if($node.Node.ChildNodes[$i].Attributes["Description"].Value -ne "")
                                {
                                    $aprojectdescription=$node.Node.ChildNodes[$i].Attributes["Description"].Value
                                }
                                CreateADGroup -OUPath $adpath -GroupScope $adgroupscope -GroupName $adgroupname.trim() -Description $aprojectdescription
                            }
            'CreateFolder' {
                                $folderpath=$node.Node.ChildNodes[$i].Attributes["Path"].Value
                                If($null -ne $RootFolder)
                                {
                                    $folderpath=$folderpath.Replace("{RootFolder}",$RootFolder)
                                }

                                $folderpath=$folderpath.Replace("{ProjectNumber}", $aprojectnumber)
                                if($folderpath.Contains("{ProjectName}") -eq $True)
                                {
                                    if($aprojectname -eq "")
                                    {
                                        $folderpath=$folderpath.Replace(" {ProjectName}", "")
                                        $folderpath=$folderpath.Replace("-{ProjectName}", "")
                                        $folderpath=$folderpath.Replace("{ProjectName}", "")
                                    }
                                    else {
                                        $folderpath=$folderpath.Replace("{ProjectName}", $aprojectname)
                                    }
                                }

                                $foldername=$node.Node.ChildNodes[$i].InnerText
				                $foldername=$foldername.Replace("{ProjectNumber}", $aprojectnumber)
				                $foldername=$foldername.Replace("{ProjectName}", $aprojectname)
                                CreateFolder -FolderPath $folderpath.trim() -FolderName $foldername.trim()
                            }
            'AddADGroupMember'{
                                $adgroupname=$node.Node.ChildNodes[$i].Attributes["Group"].Value
				                $adgroupname=$adgroupname.Replace("{ProjectNumber}",$aprojectnumber)
                                $adgroupmember=$node.Node.ChildNodes[$i].InnerText
				                $adgroupmember=$adgroupmember.Replace("{ProjectNumber}",$aprojectnumber)
                                AddADGroupMember -ADGroupName $adgroupname.trim() -Member $adgroupmember.trim()
                                }
            'GrantFolderPermission' {
                                $folderpath=$node.Node.ChildNodes[$i].Attributes["Path"].Value
                                If($null -ne $RootFolder)
                                {
                                    $folderpath=$folderpath.Replace("{RootFolder}",$RootFolder)
                                }
                                $folderpath=$folderpath.Replace("{ProjectNumber}", $aprojectnumber)
                                if($folderpath.Contains("{ProjectName}") -eq $True)
                                {
                                    if($aprojectname -eq "")
                                    {
                                        $folderpath=$folderpath.Replace(" {ProjectName}", "")
                                        $folderpath=$folderpath.Replace("-{ProjectName}", "")
                                        $folderpath=$folderpath.Replace("{ProjectName}", "")
                                    }
                                    else {
                                        $folderpath=$folderpath.Replace("{ProjectName}", $aprojectname)
                                    }
                                }
                                $permission=$node.Node.ChildNodes[$i].Attributes["Permission"].Value
                                $inheritance=$node.Node.ChildNodes[$i].Attributes["Inheritance"].Value
                                $permissiontype=$node.Node.ChildNodes[$i].Attributes["PermissionType"].Value
                                $isnew=$node.Node.ChildNodes[$i].Attributes["New"].Value
                                $userorgroup=$node.Node.ChildNodes[$i].InnerText
				                $userorgroup=$userorgroup.Replace("{ProjectNumber}",$aprojectnumber)
                                GrantFolderPermission -FolderPath $folderpath.trim() -UserOrGroups $userorgroup.trim() -Permission $permission -inheritance $inheritance -IsNew $isnew -PermissionType $permissiontype
                                }
            'RemoveFolderPermission'{
                                $folderpath=$node.Node.ChildNodes[$i].Attributes["Path"].Value
                                If($null -ne $RootFolder)
                                {
                                    $folderpath=$folderpath.Replace("{RootFolder}",$RootFolder)
                                }
                                $folderpath=$folderpath.Replace("{ProjectNumber}", $aprojectnumber)
                                if($folderpath.Contains("{ProjectName}") -eq $True)
                                {
                                    if($aprojectname -eq "")
                                    {
                                        $folderpath=$folderpath.Replace(" {ProjectName}", "")
                                        $folderpath=$folderpath.Replace("-{ProjectName}", "")
                                        $folderpath=$folderpath.Replace("{ProjectName}", "")
                                    }
                                    else {
                                        $folderpath=$folderpath.Replace("{ProjectName}", $aprojectname)
                                    }
                                }
                                $userorgroup=$node.Node.ChildNodes[$i].InnerText
				                $userorgroup=$userorgroup.Replace("{ProjectNumber}",$aprojectnumber)
                                #$permissiontype=$node.Node.ChildNodes[$i].Attributes["PermissionType"].Value
                                RemoveFolderPermissions -FolderPath $folderpath.trim() -UserOrGroups $userorgroup.trim()
                                }
            'SetFolderOwner'{
                                $folderpath=$node.Node.ChildNodes[$i].Attributes["Path"].Value
                                $folderowner=$node.Node.ChildNodes[$i].Attributes["Owner"].Value
                                If($null -ne $RootFolder)
                                {
                                    $folderpath=$folderpath.Replace("{RootFolder}",$RootFolder)
                                }
                                if($folderpath.Contains("{ProjectName}") -eq $True)
                                {
                                    if($aprojectname -eq "")
                                    {
                                        $folderpath=$folderpath.Replace(" {ProjectName}", "")
                                        $folderpath=$folderpath.Replace("-{ProjectName}", "")
                                        $folderpath=$folderpath.Replace("{ProjectName}", "")
                                    }
                                    else {
                                        $folderpath=$folderpath.Replace("{ProjectName}", $aprojectname)
                                    }
                                }
                                $folderpath=$folderpath.Replace("{ProjectNumber}", $aprojectnumber)
                                $folders=$node.Node.ChildNodes[$i].InnerText
                                $folders=$folders.Replace("{ProjectNumber}", $aprojectnumber)
                                if($folders.Contains("{ProjectName}") -eq $True)
                                {
                                    if($aprojectname -eq "")
                                    {
                                        $folders=$folderpath.Replace(" {ProjectName}", "")
                                        $folders=$folderpath.Replace("-{ProjectName}", "")
                                        $folders=$folderpath.Replace("{ProjectName}", "")
                                    }
                                    else {
                                        $folders=$folderpath.Replace("{ProjectName}", $aprojectname)
                                    }
                                }
                                SetFolderOwner -RootFolderPath $folderpath -Folders $folders -FolderOwner $folderowner
            }
        }
    }
    GenerateReport -ReportType "LogFile"

    [System.Windows.Forms.Messagebox]::Show("Task(s) completed!`nSuccess:" + $script:SuccessTaskCount + " ; Fail:" + $script:FailTaskCount)

}


## Command line mode or GUI mode
if(($NULL -ne $args[0]) -and ($NULL -ne $args[1]) -and ($NULL -ne $args[2]) -and ($NULL -ne $args[3]))
{
    if($null -ne $args[4])
    {
    $aprojectdescription=$args[4]
    }
    else {
        $aprojectdescription=""
    }
    ExecuteActions -aoffice $args[0] -ateam $args[1] -aprojectnumber $args[2] -aprojectname $args[3] -aprojectdescription $aprojectdescription
    Exit
}

function EnvironmentCheck
{
<#
$keywords='New-Object','Join-Path','Test-Path','New-Item2','New-ADGroup','Get-ADGroup','Add-ADGroupMember','Get-ADGroupMember','Add-NTFSAccess','Remove-NTFSAccess','Get-ACL','Add-Type','Select-Xml'
$r=$true
foreach($keyword in $keywords)
    {
        $r=$r -and (get-command -Name $keyword -ErrorAction Ignore)
    }
return $r
#>
    $OSversion=(get-ciminstance Win32_OperatingSystem).caption
    
    if($OSversion.Contains("Server") -eq $true)
    {
        $Module2=Get-WindowsFeature -Name RSAT-AD-PowerShell | where-object {$_.InstallState -eq "Installed"}
    }
    else
    {
        #$Module2=Get-Module -Name Activedirectory
        $Module2=get-command -name get-adgroup -ErrorAction Ignore
    }
    
    if($Module2.length -eq 0)
    {
        write-host ("Please install ActiveDirectory module before create folder. `nPS to install this module: Install-WindowsFeature RSAT-AD-PowerShell")
        [System.Windows.Forms.Messagebox]::Show("Please install ActiveDirectory module before create folder. `nPS to install this module: Install-WindowsFeature RSAT-AD-PowerShell")
        Exit
    }
}


function isFolderNameValid
{
    Param([string] $foldername
    )
    $r=!($foldername.Contains("\") -or $foldername.Contains("/") -or $foldername.Contains(":") -or $foldername.Contains("*") -or $foldername.Contains("?") -or $foldername.Contains("""") -or $foldername.Contains("<") -or $foldername.Contains(">") -or $foldername.Contains("|"))
    return $r
}


function RefreshTeam
{
    Param([string] $Office
    )
    $TeamList.Items.Clear()
    for($o=0;$o -le $xmldata.Offices.ChildNodes.Count-1;$o++)
    {
        if($xmldata.Offices.ChildNodes[$o].Name -eq $Office)
        {
            foreach($TeamName in $xmldata.Offices.ChildNodes[$o].Team)
            {
                if($TeamName.Attributes["Status"].Value -eq "Active")
                {
                    $TeamList.Items.Add($TeamName.Attributes["Name"].Value)
                }
            }
        }
    }
}


#### create GUI#######
Add-Type -AssemblyName System.Windows.Forms
$PowerShellForms = New-Object system.Windows.Forms.Form
$PowerShellForms.Text=$FormTitle
$PowerShellForms.Size = New-Object System.Drawing.Size(550,550)
$PowerShellForms.MinimizeBox = $False
$PowerShellForms.MaximizeBox = $False
$PowerShellForms.FormBorderStyle = [System.Windows.Forms.FormBorderStyle]::FixedDialog

$PowerShellForms.SizeGripStyle = "Hide"
$Icons = [system.drawing.icon]::ExtractAssociatedIcon($PSHOME + "\powershell.exe")
$PowerShellForms.Icon = $Icons
$PowerShellForms.StartPosition = "CenterScreen"
$PowerShellForms.Font = New-Object System.Drawing.Font("Tahoma",10,[System.Drawing.FontStyle]::Regular)
$PowerShellForms.Add_Load({EnvironmentCheck})



$Lboffice = New-Object System.Windows.Forms.Label
$Lboffice.Text = "Office(*)"
$Lboffice.AutoSize = $True
$Lboffice.BackColor = "Transparent"
$Lboffice.Font = New-Object System.Drawing.Font("Tahoma",10,[System.Drawing.FontStyle]::Regular)
$Lboffice.ForeColor = "Black"
$Lboffice.Location = New-Object System.Drawing.Point(10,25)

$OfficeList = New-Object System.Windows.Forms.ListBox
$OfficeList.Font = New-Object System.Drawing.Font("Tahoma",10,[System.Drawing.FontStyle]::Regular)
$OfficeList.Location = New-Object System.Drawing.Point(120,25)
$OfficeList.Size = New-Object System.Drawing.Size(400,20)
$OfficeList.Height = 90
for($o=0;$o -le $xmldata.Offices.ChildNodes.Count-1;$o++)
{
    if($xmldata.Offices.ChildNodes[$o].Attributes["Status"].Value -eq "Active")
    {
        $OfficeList.items.Add($xmldata.Offices.ChildNodes[$o].Name)
    }
}
$OfficeList.TabIndex = 1
$OfficeList.Add_SelectedIndexChanged(
    {
        RefreshTeam -Office $OfficeList.SelectedItem.ToString()
    }
)

$LbTeam = New-Object System.Windows.Forms.Label
$LbTeam.Text = "Team(*)"
$LbTeam.AutoSize = $True
$LbTeam.BackColor = "Transparent"
$LbTeam.Font = New-Object System.Drawing.Font("Tahoma",10,[System.Drawing.FontStyle]::Regular)
$LbTeam.ForeColor = "Black"
$LbTeam.Location = New-Object System.Drawing.Point(10,125)

$TeamList = New-Object System.Windows.Forms.ListBox
$TeamList.Font = New-Object System.Drawing.Font("Tahoma",10,[System.Drawing.FontStyle]::Regular)
$TeamList.Location = New-Object System.Drawing.Point(120,125)
$TeamList.Size = New-Object System.Drawing.Size(400,100)
$TeamList.Height=60
#Group name length limit is 64, group name example: 
$TeamList.TabIndex = 2


$LbProjectNumber = New-Object System.Windows.Forms.Label
$LbProjectNumber.Text = "Project No.(*)"
$LbProjectNumber.AutoSize = $True
$LbProjectNumber.BackColor = "Transparent"
$LbProjectNumber.Font = New-Object System.Drawing.Font("Tahoma",10,[System.Drawing.FontStyle]::Regular)
$LbProjectNumber.ForeColor = "Black"
$LbProjectNumber.Location = New-Object System.Drawing.Point(10,185)

$ProjectNumber = New-Object System.Windows.Forms.TextBox
$ProjectNumber.Font = New-Object System.Drawing.Font("Tahoma",10,[System.Drawing.FontStyle]::Regular)
$ProjectNumber.Location = New-Object System.Drawing.Point(120,185)
$ProjectNumber.Size = New-Object System.Drawing.Size(400,100)
#Group name length limit is 64, group name example: GRP-FSU-CNGGZ100-123456 or GRP-FSU-CNGGZ100-MEP-123456-M
$ProjectNumber.MaxLength = 15
$ProjectNumber.TabIndex = 3
$global:ProjectNumberStatus=$False
$global:ProjectNameStatus=$True
$ProjectNumber.add_TextChanged({
    #if($ProjectNumber.Text -match '[^-\w\.]')
    if($ProjectNumber.Text -match '[^-\s\w\.]')
    {
        [System.Windows.Forms.Messagebox]::Show("Project number only allow: A-Z a-z 0-9 -_")
        $global:ProjectNumberStatus=$False
        $LbProjectNumber.ForeColor="Red"
    }
    else
    {
        $global:ProjectNumberStatus=$True
        $LbProjectNumber.ForeColor="Black"
    }
    $BtnOK.enabled=($global:ProjectNameStatus -and $global:ProjectNumberStatus)
})


$LbProjectName = New-Object System.Windows.Forms.Label
$LbProjectName.Text = "Project Name"
$LbProjectName.AutoSize = $True
$LbProjectName.BackColor = "Transparent"
$LbProjectName.Font = New-Object System.Drawing.Font("Tahoma",10,[System.Drawing.FontStyle]::Regular)
$LbProjectName.ForeColor = "Black"
$LbProjectName.Location = New-Object System.Drawing.Point(10,225)

$ProjectName = New-Object System.Windows.Forms.TextBox
$ProjectName.Font = New-Object System.Drawing.Font("Tahoma",10,[System.Drawing.FontStyle]::Regular)
$ProjectName.Location = New-Object System.Drawing.Point(120,225)
$ProjectName.Size = New-Object System.Drawing.Size(400,100)
$ProjectName.MaxLength = 32
#Project name length limit is 32
$ProjectName.TabIndex = 4
$ProjectName.add_TextChanged({
    if($ProjectName.Text -match '[^-\w\. ]')
    {
        [System.Windows.Forms.Messagebox]::Show("Project name only allow: A-Z a-z 0-9 -_ and space")
        $global:ProjectNameStatus=$False
        $LbProjectName.ForeColor="Red"
    }
    else
    {
        $global:ProjectNameStatus=$True
        $LbProjectName.ForeColor="Black"
    }
    $BtnOK.enabled=($global:ProjectNameStatus -and $global:ProjectNumberStatus)
})


$LbProjectDescription = New-Object System.Windows.Forms.Label
$LbProjectDescription.Text = "Description"
$LbProjectDescription.AutoSize = $True
$LbProjectDescription.BackColor = "Transparent"
$LbProjectDescription.Font = New-Object System.Drawing.Font("Tahoma",10,[System.Drawing.FontStyle]::Regular)
$LbProjectDescription.ForeColor = "Black"
$LbProjectDescription.Location = New-Object System.Drawing.Point(10,265)

$ProjectDescription = New-Object System.Windows.Forms.TextBox
$ProjectDescription.Font = New-Object System.Drawing.Font("Tahoma",10,[System.Drawing.FontStyle]::Regular)
$ProjectDescription.Location = New-Object System.Drawing.Point(120,265)
$ProjectDescription.Size = New-Object System.Drawing.Size(400,100)
$ProjectDescription.TabIndex = 5


$LbResultList = New-Object System.Windows.Forms.Label
$LbResultList.Text = "Result"
$LbResultList.AutoSize = $True
$LbResultList.BackColor = "Transparent"
$LbResultList.Font = New-Object System.Drawing.Font("Tahoma",10,[System.Drawing.FontStyle]::Regular)
$LbResultList.ForeColor = "Black"
$LbResultList.Location = New-Object System.Drawing.Point(10,315)

$ResultList = New-Object System.Windows.Forms.ListBox
$ResultList.Font = New-Object System.Drawing.Font("Tahoma",10,[System.Drawing.FontStyle]::Regular)
$ResultList.Location = New-Object System.Drawing.Point(120,315)
$ResultList.Size = New-Object System.Drawing.Size(400,100)
$ResultList.HorizontalScrollbar = $True
$ResultList.BackColor = [System.Drawing.Color]::Gray


$BtnResult2Clipboard = New-Object System.Windows.Forms.Button
$BtnResult2Clipboard.Size = New-Object System.Drawing.Size(30,30)
$BtnResult2Clipboard.Location = New-Object System.Drawing.Size(120,420)
$BtnResult2Clipboard.Text = "C"
$tt1=New-Object System.Windows.Forms.ToolTip
$tt1.SetToolTip($BtnResult2Clipboard,"Copy result to clipboard")
$BtnResult2Clipboard.Font = New-Object System.Drawing.Font("Tahoma",10,[System.Drawing.FontStyle]::Regular)
$BtnResult2Clipboard.Add_Click(
    {
        GenerateReport -ReportType "Clipboard"
    }
)

$BtnResult2File = New-Object System.Windows.Forms.Button
$BtnResult2File.Size = New-Object System.Drawing.Size(30,30)
$BtnResult2File.Location = New-Object System.Drawing.Size(160,420)
$BtnResult2File.Text = "E"
$tt2=New-Object System.Windows.Forms.ToolTip
$tt2.SetToolTip($BtnResult2File,"Export result to log file")
$BtnResult2File.Font = New-Object System.Drawing.Font("Tahoma",10,[System.Drawing.FontStyle]::Regular)
$BtnResult2File.Add_Click(
    {
        GenerateReport -ReportType "LogFile"
    }
)

$BtnOK = New-Object System.Windows.Forms.Button
$btnOK.Size = New-Object System.Drawing.Size(100,40)
$BtnOK.Location = New-Object System.Drawing.Size(420,420)
$BtnOK.Text = "Create"
$BtnOK.Font = New-Object System.Drawing.Font("Tahoma",10,[System.Drawing.FontStyle]::Regular)
$BtnOK.Add_Click(
    {
        $ResultList.Items.Clear()
        $script:SuccessTaskCount=0;
        $script:FailTaskCount=0;
        
        $txtprojectnumber=$ProjectNumber.Text.Trim()
        $txtprojectname=$ProjectName.Text.Trim()
        if(($null -ne $OfficeList.SelectedItem) -and ($null -ne $TeamList.SelectedItem) -and ($txtprojectnumber.Length -ne 0))
        {
            $r=(isFolderNameValid -foldername $txtprojectnumber) -and (isFolderNameValid -foldername $txtprojectname)
            if($r -eq $true)
            {
                ExecuteActions -aoffice $OfficeList.SelectedItem -ateam $TeamList.SelectedItem -aprojectnumber $txtprojectnumber -aprojectname $txtprojectname -aprojectdescription $ProjectDescription.Text.Trim()
            }
            else
            {
                [System.Windows.Forms.Messagebox]::Show("Project number or name invalid")
            }
        }
        else
        {
            [System.Windows.Forms.Messagebox]::Show("Following items are mandatory: `nOffice`nTeam`nProject No.")
        }
    }
)

$TabControl1 = New-Object System.Windows.Forms.TabControl
$tabPage1=New-Object System.Windows.Forms.TabPage
$tabPage1.text = "Create Project"
$tabPage1.TabIndex=0
$tabPage1.Controls.AddRange(($Lboffice, $OfficeList, $LbTeam, $TeamList, $LbProjectNumber, $ProjectNumber, $LbProjectName, $ProjectName, $LbProjectDescription, $ProjectDescription, $LbResultList,$ResultList,$BtnResult2Clipboard,$BtnResult2File, $BtnOK))

$TabControl1.Controls.Add($tabPage1)
$TabControl1.Location = New-Object System.Drawing.Point(0,0)
$TabControl1.Size=$PowerShellForms.Size
$Tabcontrol1.Add_SelectedIndexChanged(
    {
        $TabControl1.TabPages[$TabControl1.SelectedIndex].Controls.AddRange(($Lboffice, $OfficeList, $LbTeam, $TeamList))
    }
)

$PowerShellForms.Controls.Add($TabControl1)

$PowerShellForms.ShowDialog()