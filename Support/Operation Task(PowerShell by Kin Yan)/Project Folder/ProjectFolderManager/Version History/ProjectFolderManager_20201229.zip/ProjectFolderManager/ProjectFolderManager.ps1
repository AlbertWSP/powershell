###
#Requirement: 1) PowerShell 5.x(not compatible with PS7.x); 2) RSAT-AD-PowerShell feature installed; 3. NTFSSecurity module installed

#1. enable PS:  Set-ExecutionPolicy RemoteSigned
#2. import "File System Security PowerShell Module"  https://www.powershellgallery.com/packages/NTFSSecurity/
#   you can follow below 2 methods to install this module:
#   1) by command(local admin with internet access):    Install-Module -Name NTFSSecurity
#    or
#   2) copy \\cnggz100dat01\it\Software\Server\NTFSSecurity folder to C:\Program Files\WindowsPowerShell\Modules
#3. install RSAT-AD-PowerShell feature by PS command: Install-WindowsFeature RSAT-AD-PowerShell

 

#Author: Kin.Yan@wsp.com
#Description: This is the most powerful tool for project folder management in the planet, i'm not joking, you can feel how powerful it is.......from the window title :)
#Last update:2020/12/28
###


$FormTitle="Project Folder Manager Pro Plus Ultimate"

$ProfilePath = "C:\Support\ProjectFolderManager\ProjectFolders.xml"
$global:xmldata = New-Object -TypeName XML
$global:xmldata.Load($ProfilePath)

$global:exitcode = 1
$global:RootFolder=""
$global:PermissionPrefix=""
# success=1, fail=9


########################################Action Start##########################################
function CreateADGroup
{
    Param(  [string] $GroupName,
	        [string] $GroupScope,
            [string] $Description,
            [string] $OUPath)
    
    $resultprefix=""
    try {
        New-ADGroup -name $GroupName -GroupScope $GroupScope -Description $Description -path $OUPath
        $resultprefix="[Succeeded] "
        $global:exitcode=1
        #return $False
    }
    catch
    {
        $resultprefix="[Fail] "
        $exitcode=9
        #return $true
    }

    if($ResultList)
    {
        $ResultList.Items.Add($resultprefix + "Create AD group: " + $GroupName)
    }
    else {
        write-host ($resultprefix + "Create AD group: " + $GroupName)
    }
}

function CreateFolder
{
    Param([string] $FolderPath,
          [string] $FolderName
    )

    $resultprefix=""
    $fullpath=Join-Path $FolderPath $FolderName
    try {
        New-Item -Path $fullpath -ItemType Directory
        $resultprefix="[Succeeded] "
        $global:exitcode=1
        #return $True
        }
    catch
    {
        $resultprefix="[Fail] "
        $exitcode=9
        #return $False
    }

    if($ResultList)
    {
        $ResultList.Items.Add($resultprefix + "Create folder: " + $fullpath)
    }
    else {
        write-host ($resultprefix + "Create folder: " + $fullpath)
    }
}

function AddADGroupMember
{
    Param([string] $ADGroupName,
          [string] $Member
    )
    $resultprefix=""    
    try {
        Add-ADGroupMember $ADGroupName -Members $Member
        $resultprefix="[Succeeded] "
        $global:exitcode=1
        #return $True
        }
    catch
    {
        $resultprefix="[Fail] "
        $exitcode=9
        #return $False
    }

    if($ResultList)
    {
        $ResultList.Items.Add($resultprefix + "Add AD group member: Member: " + $Member + "; ADGroup:" + $ADGroupName)
    }
    else {
        write-host ($resultprefix + "Add AD group member: Member: " + $Member + "; ADGroup:" + $ADGroupName)
    }
}

function GrantFolderPermission
{
    Param([string] $FolderPath,
          [string] $UserOrGroup,
          [string] $Permission
    )

    $resultprefix=""

    if((Test-Path $FolderPath) -eq $True)
    {
        try {
            Add-NTFSAccess -Path $FolderPath -Account $UserOrGroup -AccessRights $Permission -AccessType Allow
            $resultprefix="[Succeeded] "
            $global:exitcode=1
            #return $True
        }
        catch
        {
            $resultprefix="[Fail] "
            $exitcode=9
            #return $False
        }
    }
    else
    {
        $resultprefix="[Fail] "
        $exitcode=9
        #return $False
    }

    if($ResultList)
    {
        $ResultList.Items.Add($resultprefix + "Grant folder permission: Folder: " + $FolderPath + "; UserOrGroup: " + $UserOrGroup + "; Permission: " + $Permission)
    }
    else {
        write-host ($resultprefix + "Grant folder permission: Folder: " + $FolderPath + "; UserOrGroup: " + $UserOrGroup + "; Permission: " + $Permission)
    }    
}

function RemoveUserPermission
{
    Param([string] $FolderPath,
          [string] $UserOrGroup
    )

    $resultprefix=""
    if((Test-Path $FolderPath) -eq $True)
    {
        try {
                $acl = Get-Acl $FolderPath
                $acl.SetAccessRuleProtection($True, $True)
                Set-Acl $FolderPath $acl | Out-Null
                Remove-NTFSAccess -path $FolderPath -Account $UserOrGroup -AccessRights FullControl
                $resultprefix="[Succeeded] "
                $global:exitcode=1
                #return $True
                }
        catch{
                $resultprefix="[Fail] "
                $exitcode=9
                #return $False
            }
    }
    else
    {
        $resultprefix="[Fail] "
        $exitcode=9
        #return $False    
    }

    if($ResultList)
    {
        $ResultList.Items.Add($resultprefix + "Remove folder permission: Folder: " + $FolderPath + "; UserOrGroup: " + $UserOrGroup)
    }
    else {
        write-host ($resultprefix + "Remove folder permission: Folder: " + $FolderPath + "; UserOrGroup: " + $UserOrGroup)
    }    
}



##############################Action End################################################
function getTeamNode()
{
    Param(  [string] $aoffice,
            [string] $ateam
    )
    $xp="//Office[@Name='" + $aoffice + "']/Team[@Name='" + $ateam + "']"
    $node=$global:xmldata | Select-Xml -XPath $xp
    return $node
}

function ExecuteActions()
{
    Param(  [string] $aoffice,
            [string] $ateam,
            [string] $aprojectnumber,
            [string] $aprojectname,
            [string] $aprojectdescription
    )

    <#
    $xp="//Office[@Name='" + $aoffice + "']/Team[@Name='" + $ateam + "']"
    $node=$xmldata | Select-Xml -XPath $xp
    #>
    $node=getTeamNode -aoffice $aoffice -ateam $ateam
    $global:RootFolder=$node.Node.Attributes["RootFolder"].Value
    for($i=0;$i -lt $node.Node.ChildNodes.Count; $i++)
    {
        Switch($node.Node.ChildNodes[$i].Attributes["Type"].Value)
        {
            'CreateADGroup' {
                                $adpath=$node.Node.ChildNodes[$i].Attributes["OU"].Value
                                $adgroupname=$node.Node.ChildNodes[$i].InnerText
                                ##$adgroupname=FormatName -namestring $adgroupname -type Group
				                $adgroupname=$adgroupname.Replace("{ProjectNumber}",$aprojectnumber)
                                $adgroupscope=$node.Node.ChildNodes[$i].Attributes["Scope"].Value
                                if($node.Node.ChildNodes[$i].Attributes["Description"].Value -ne "")
                                {
                                    $aprojectdescription=$node.Node.ChildNodes[$i].Attributes["Description"].Value
                                }
                                CreateADGroup -OUPath $adpath -GroupScope $adgroupscope -GroupName $adgroupname -Description $aprojectdescription
                            }
            'CreateFolder' {
                                $folderpath=$node.Node.ChildNodes[$i].Attributes["Path"].Value
                                If($null -ne $RootFolder)
                                {
                                    $folderpath=$folderpath.Replace("{RootFolder}",$RootFolder)
                                }
                                $folderpath=$folderpath.Replace("{ProjectNumber}", $aprojectnumber)
				                $folderpath=$folderpath.Replace("{ProjectName}", $aprojectname)

                                ##$folderpath=FormatName -namestring $folderpath -type Folder
                                $foldername=$node.Node.ChildNodes[$i].InnerText
                                ##$foldername=FormatName -namestring $foldername -type Folder
				                $foldername=$foldername.Replace("{ProjectNumber}", $aprojectnumber)
				                $foldername=$foldername.Replace("{ProjectName}", $aprojectname)
                                CreateFolder -FolderPath $folderpath -FolderName $foldername
                            }
            'AddADGroupMember'{
                                $adgroupname=$node.Node.ChildNodes[$i].Attributes["Group"].Value
				                $adgroupname=$adgroupname.Replace("{ProjectNumber}",$aprojectnumber)
                                ##$adgroupname=FormatName -namestring $adgroupname -type Group
                                $adgroupmember=$node.Node.ChildNodes[$i].InnerText
				                $adgroupmember=$adgroupmember.Replace("{ProjectNumber}",$aprojectnumber)
                                ##$adgroupmember=FormatName -namestring $adgroupmember -type Group
                                AddADGroupMember -ADGroupName $adgroupname -Member $adgroupmember
                                }
            'GrantFolderPermission' {
                                $folderpath=$node.Node.ChildNodes[$i].Attributes["Path"].Value
                                If($null -ne $RootFolder)
                                {
                                    $folderpath=$folderpath.Replace("{RootFolder}",$RootFolder)
                                }
                                ##$folderpath=FormatName -namestring $folderpath -type Folder
				                $folderpath=$folderpath.Replace("{ProjectNumber}", $aprojectnumber)
				                $folderpath=$folderpath.Replace("{ProjectName}", $aprojectname)
                                $userorgroup=$node.Node.ChildNodes[$i].Attributes["UserOrGroup"].Value
                                ##$userorgroup=FormatName -namestring $userorgroup -type Group
				                $userorgroup=$userorgroup.Replace("{ProjectNumber}",$aprojectnumber)
                                $permission=$node.Node.ChildNodes[$i].InnerText
                                GrantFolderPermission -FolderPath $folderpath -UserOrGroup $userorgroup -Permission $permission
                                }
            'RemoveUserPermission'{
                                $folderpath=$node.Node.ChildNodes[$i].Attributes["Path"].Value
                                If($null -ne $RootFolder)
                                {
                                    $folderpath=$folderpath.Replace("{RootFolder}",$RootFolder)
                                }
                                ##$folderpath=FormatName -namestring $folderpath -type Folder
				                $folderpath=$folderpath.Replace("{ProjectNumber}", $aprojectnumber)
				                $folderpath=$folderpath.Replace("{ProjectName}", $aprojectname)
                                $userorgroup=$node.Node.ChildNodes[$i].InnerText
                                ##$userorgroup=FormatName -namestring $userorgroup -type Group
				                $userorgroup=$userorgroup.Replace("{ProjectNumber}",$aprojectnumber)
                                RemoveUserPermission -FolderPath $folderpath -UserOrGroup $userorgroup
                                }
        }
                
    }
    [System.Windows.Forms.Messagebox]::Show("Done!")
}


## Command line mode or GUI mode
if(($NULL -ne $args[0]) -and ($NULL -ne $args[1]) -and ($NULL -ne $args[2]) -and ($NULL -ne $args[3]))
{
    if($null -ne $args[4])
    {
    $aprojectdescription=$args[4]
    }
    else {
        $aprojectdescription=""
    }
    ExecuteActions -aoffice $args[0] -ateam $args[1] -aprojectnumber $args[2] -aprojectname $args[3] -aprojectdescription $aprojectdescription
    Exit
}



function EnvironmentCheck
{
<#
$keywords='New-Object','Join-Path','Test-Path','New-Item2','New-ADGroup','Get-ADGroup','Add-ADGroupMember','Get-ADGroupMember','Add-NTFSAccess','Remove-NTFSAccess','Get-ACL','Add-Type','Select-Xml'
$r=$true
foreach($keyword in $keywords)
    {
        $r=$r -and (get-command -Name $keyword -ErrorAction Ignore)
    }
return $r
#>
    $OSversion=(get-ciminstance Win32_OperatingSystem).caption
    $Module1=get-Installedmodule -name NTFSSecurity
    if($OSversion.Contains("Server") -eq $true)
    {
        $Module2=Get-WindowsFeature -Name RSAT-AD-PowerShell | where-object {$_.InstallState -eq "Installed"}
    }
    else
    {
        #$Module2=Get-Module -Name Activedirectory
        $Module2=get-command -name get-adgroup -ErrorAction Ignore
    }
    if($null -eq $Module1)
    {
        [System.Windows.Forms.Messagebox]::Show("Please install NTFSSecurity module before create folder.`nPS to install this module: Install-Module -Name NTFSSecurity `nOR`ncopy \\cnggz100dat01\it\Software\Server\NTFSSecurity folder to C:\Program Files\WindowsPowerShell\Modules")
    }

    if($Module2.length -eq 0)
    {
        [System.Windows.Forms.Messagebox]::Show("Please install ActiveDirectory module before create folder. `nPS to install this module: Install-WindowsFeature RSAT-AD-PowerShell")
        
    }
}


function isFolderNameValid
{
    Param([string] $foldername
    )
    $r=!($foldername.Contains("\") -or $foldername.Contains("/") -or $foldername.Contains(":") -or $foldername.Contains("*") -or $foldername.Contains("?") -or $foldername.Contains("""") -or $foldername.Contains("<") -or $foldername.Contains(">") -or $foldername.Contains("|"))
    return $r
}


function RefreshTeam
{
    Param([string] $Office
    )
    $TeamList.Items.Clear()
    for($o=0;$o -le $xmldata.Offices.ChildNodes.Count-1;$o++)
    {
        if($xmldata.Offices.ChildNodes[$o].Name -eq $Office)
        {
            foreach($TeamName in $xmldata.Offices.ChildNodes[$o].Team)
            {
                if($TeamName.Attributes["Status"].Value -eq "Active")
                {
                    $TeamList.Items.Add($TeamName.Attributes["Name"].Value)
                    #$node.Node.Attributes["RootFolder"].Value
                }
            }
        }
    }
}


#### create GUI#######
Add-Type -AssemblyName System.Windows.Forms
$PowerShellForms = New-Object system.Windows.Forms.Form
$PowerShellForms.Text=$FormTitle
$PowerShellForms.Size = New-Object System.Drawing.Size(550,550)
$PowerShellForms.MinimizeBox = $False
$PowerShellForms.MaximizeBox = $False
$PowerShellForms.FormBorderStyle = [System.Windows.Forms.FormBorderStyle]::FixedDialog

$PowerShellForms.SizeGripStyle = "Hide"
$Icons = [system.drawing.icon]::ExtractAssociatedIcon($PSHOME + "\powershell.exe")
$PowerShellForms.Icon = $Icons
$PowerShellForms.StartPosition = "CenterScreen"
$PowerShellForms.Font = New-Object System.Drawing.Font("Tahoma",10,[System.Drawing.FontStyle]::Regular)
$PowerShellForms.Add_Load({EnvironmentCheck})



$Lboffice = New-Object System.Windows.Forms.Label
$Lboffice.Text = "Office(*)"
$Lboffice.AutoSize = $True
$Lboffice.BackColor = "Transparent"
$Lboffice.Font = New-Object System.Drawing.Font("Tahoma",10,[System.Drawing.FontStyle]::Regular)
$Lboffice.ForeColor = "Black"
$Lboffice.Location = New-Object System.Drawing.Point(10,25)

$OfficeList = New-Object System.Windows.Forms.ListBox
$OfficeList.Font = New-Object System.Drawing.Font("Tahoma",10,[System.Drawing.FontStyle]::Regular)
$OfficeList.Location = New-Object System.Drawing.Point(120,25)
$OfficeList.Size = New-Object System.Drawing.Size(400,20)
$OfficeList.Height = 90
for($o=0;$o -le $xmldata.Offices.ChildNodes.Count-1;$o++)
{
    if($xmldata.Offices.ChildNodes[$o].Attributes["Status"].Value -eq "Active")
    {
        $OfficeList.items.Add($xmldata.Offices.ChildNodes[$o].Name)
    }
}
$OfficeList.TabIndex = 1
$OfficeList.Add_SelectedIndexChanged(
    {
        RefreshTeam -Office $OfficeList.SelectedItem.ToString()
    }
)

$LbTeam = New-Object System.Windows.Forms.Label
$LbTeam.Text = "Team(*)"
$LbTeam.AutoSize = $True
$LbTeam.BackColor = "Transparent"
$LbTeam.Font = New-Object System.Drawing.Font("Tahoma",10,[System.Drawing.FontStyle]::Regular)
$LbTeam.ForeColor = "Black"
$LbTeam.Location = New-Object System.Drawing.Point(10,125)

$TeamList = New-Object System.Windows.Forms.ListBox
$TeamList.Font = New-Object System.Drawing.Font("Tahoma",10,[System.Drawing.FontStyle]::Regular)
$TeamList.Location = New-Object System.Drawing.Point(120,125)
$TeamList.Size = New-Object System.Drawing.Size(400,100)
$TeamList.Height=60
#Group name length limit is 64, group name example: 
$TeamList.TabIndex = 2


$LbProjectNumber = New-Object System.Windows.Forms.Label
$LbProjectNumber.Text = "Project No.(*)"
$LbProjectNumber.AutoSize = $True
$LbProjectNumber.BackColor = "Transparent"
$LbProjectNumber.Font = New-Object System.Drawing.Font("Tahoma",10,[System.Drawing.FontStyle]::Regular)
$LbProjectNumber.ForeColor = "Black"
$LbProjectNumber.Location = New-Object System.Drawing.Point(10,185)

$ProjectNumber = New-Object System.Windows.Forms.TextBox
$ProjectNumber.Font = New-Object System.Drawing.Font("Tahoma",10,[System.Drawing.FontStyle]::Regular)
$ProjectNumber.Location = New-Object System.Drawing.Point(120,185)
$ProjectNumber.Size = New-Object System.Drawing.Size(400,100)
#Group name length limit is 64, group name example: GRP-FSU-CNGGZ100-123456 or GRP-FSU-CNGGZ100-MEP-123456-M
$ProjectNumber.MaxLength = 10
$ProjectNumber.TabIndex = 3
$global:ProjectNumberStatus=$False
$global:ProjectNameStatus=$True
$ProjectNumber.add_TextChanged({
    if($ProjectNumber.Text -match '[^-\w\.]')
    {
        [System.Windows.Forms.Messagebox]::Show("Project number only allow: A-Z a-z 0-9 -_")
        $global:ProjectNumberStatus=$False
        $LbProjectNumber.ForeColor="Red"
    }
    else
    {
        $global:ProjectNumberStatus=$True
        $LbProjectNumber.ForeColor="Black"
    }
    $BtnOK.enabled=($global:ProjectNameStatus -and $global:ProjectNumberStatus)
})


$LbProjectName = New-Object System.Windows.Forms.Label
$LbProjectName.Text = "Project Name"
$LbProjectName.AutoSize = $True
$LbProjectName.BackColor = "Transparent"
$LbProjectName.Font = New-Object System.Drawing.Font("Tahoma",10,[System.Drawing.FontStyle]::Regular)
$LbProjectName.ForeColor = "Black"
$LbProjectName.Location = New-Object System.Drawing.Point(10,225)

$ProjectName = New-Object System.Windows.Forms.TextBox
$ProjectName.Font = New-Object System.Drawing.Font("Tahoma",10,[System.Drawing.FontStyle]::Regular)
$ProjectName.Location = New-Object System.Drawing.Point(120,225)
$ProjectName.Size = New-Object System.Drawing.Size(400,100)
$ProjectName.MaxLength = 32
#Project name length limit is 32
$ProjectName.TabIndex = 4
$ProjectName.add_TextChanged({
    if($ProjectName.Text -match '[^-\w\. ]')
    {
        [System.Windows.Forms.Messagebox]::Show("Project name only allow: A-Z a-z 0-9 -_ and space")
        $global:ProjectNameStatus=$False
        $LbProjectName.ForeColor="Red"
    }
    else
    {
        $global:ProjectNameStatus=$True
        $LbProjectName.ForeColor="Black"
    }
    $BtnOK.enabled=($global:ProjectNameStatus -and $global:ProjectNumberStatus)
})


$LbProjectDescription = New-Object System.Windows.Forms.Label
$LbProjectDescription.Text = "Description"
$LbProjectDescription.AutoSize = $True
$LbProjectDescription.BackColor = "Transparent"
$LbProjectDescription.Font = New-Object System.Drawing.Font("Tahoma",10,[System.Drawing.FontStyle]::Regular)
$LbProjectDescription.ForeColor = "Black"
$LbProjectDescription.Location = New-Object System.Drawing.Point(10,265)

$ProjectDescription = New-Object System.Windows.Forms.TextBox
$ProjectDescription.Font = New-Object System.Drawing.Font("Tahoma",10,[System.Drawing.FontStyle]::Regular)
$ProjectDescription.Location = New-Object System.Drawing.Point(120,265)
$ProjectDescription.Size = New-Object System.Drawing.Size(400,100)
$ProjectDescription.TabIndex = 5


$LbResultList = New-Object System.Windows.Forms.Label
$LbResultList.Text = "Result"
$LbResultList.AutoSize = $True
$LbResultList.BackColor = "Transparent"
$LbResultList.Font = New-Object System.Drawing.Font("Tahoma",10,[System.Drawing.FontStyle]::Regular)
$LbResultList.ForeColor = "Black"
$LbResultList.Location = New-Object System.Drawing.Point(10,315)

$ResultList = New-Object System.Windows.Forms.ListBox
$ResultList.Font = New-Object System.Drawing.Font("Tahoma",10,[System.Drawing.FontStyle]::Regular)
$ResultList.Location = New-Object System.Drawing.Point(120,315)
$ResultList.Size = New-Object System.Drawing.Size(400,100)
$ResultList.HorizontalScrollbar = $True
$ResultList.BackColor = [System.Drawing.Color]::Gray

$BtnResult2Clipboard = New-Object System.Windows.Forms.Button
$BtnResult2Clipboard.Size = New-Object System.Drawing.Size(30,30)
$BtnResult2Clipboard.Location = New-Object System.Drawing.Size(120,420)
$BtnResult2Clipboard.Text = "C"
$tt1=New-Object System.Windows.Forms.ToolTip
$tt1.SetToolTip($BtnResult2Clipboard,"Copy result to clipboard")
$BtnResult2Clipboard.Font = New-Object System.Drawing.Font("Tahoma",10,[System.Drawing.FontStyle]::Regular)
$BtnResult2Clipboard.Add_Click(
    {
        foreach ($item in $ResultList.Items) {
            $R=$item + "`r`n" + $R
        }
        $ReportHeader="Office: " + $OfficeList.SelectedItem.ToString() + "`r`n" 
        $ReportHeader= $ReportHeader + "Team: " + $TeamList.SelectedItem.ToString() + "`r`n"
        $ReportHeader= $ReportHeader + "Project No.: " + $ProjectNumber.Text + "`r`n"
        $ReportHeader= $ReportHeader + "Project Name: " + $ProjectName.Text + "`r`n"
        $ReportHeader= $ReportHeader + "Description: " + $ProjectDescription.Text + "`r`n"
        $ReportHeader= $ReportHeader + "Tasks: " + "`r`n"

        $R=$ReportHeader + $R
        $R | Set-Clipboard
        [System.Windows.Forms.Messagebox]::Show("Result copied to clipboard")
    }
)

$BtnResult2File = New-Object System.Windows.Forms.Button
$BtnResult2File.Size = New-Object System.Drawing.Size(30,30)
$BtnResult2File.Location = New-Object System.Drawing.Size(160,420)
$BtnResult2File.Text = "E"
$tt2=New-Object System.Windows.Forms.ToolTip
$tt2.SetToolTip($BtnResult2File,"Export result to log file")
$BtnResult2File.Font = New-Object System.Drawing.Font("Tahoma",10,[System.Drawing.FontStyle]::Regular)
$BtnResult2File.Add_Click(
    {
        foreach ($item in $ResultList.Items) {
            $R=$item + "`r`n" + $R
        }
        $ReportHeader="Office: " + $OfficeList.SelectedItem.ToString() + "`r`n" 
        $ReportHeader= $ReportHeader + "Team: " + $TeamList.SelectedItem.ToString() + "`r`n"
        $ReportHeader= $ReportHeader + "Project No.: " + $ProjectNumber.Text + "`r`n"
        $ReportHeader= $ReportHeader + "Project Name: " + $ProjectName.Text + "`r`n"
        $ReportHeader= $ReportHeader + "Description: " + $ProjectDescription.Text + "`r`n"
        $ReportHeader= $ReportHeader + "Tasks: " + "`r`n"

        $R=$ReportHeader + $R
        #$R | Set-Clipboard
        #[System.Windows.Forms.Messagebox]::Show("Result copied to clipboard")
        $SaveFileDialog = New-Object windows.forms.savefiledialog
        $SaveFileDialog.initialDirectory = [System.IO.Directory]::GetCurrentDirectory()
        $SaveFileDialog.title = "Save Result to..."
        $SaveFileDialog.filter = "Most Powerful Log File In the Planet^_^|*.txt"
        $result = $SaveFileDialog.ShowDialog()    
        $result 
        if($result -eq "OK")    {    
                Write-Host "Selected File and Location:"  -ForegroundColor Green  
                $R | Out-File -FilePath $SaveFileDialog.filename   
            }

    }
)

$BtnOK = New-Object System.Windows.Forms.Button
$btnOK.Size = New-Object System.Drawing.Size(100,40)
$BtnOK.Location = New-Object System.Drawing.Size(420,420)
$BtnOK.Text = "Create"
$BtnOK.Font = New-Object System.Drawing.Font("Tahoma",10,[System.Drawing.FontStyle]::Regular)
$BtnOK.Add_Click(
    {
        $ResultList.Items.Clear()
        
        $txtprojectnumber=$ProjectNumber.Text.Trim()
        $txtprojectname=$ProjectName.Text.Trim()
        if(($null -ne $OfficeList.SelectedItem) -and ($null -ne $TeamList.SelectedItem) -and ($txtprojectnumber.Length -ne 0))
        {
            $r=(isFolderNameValid -foldername $txtprojectnumber) -and (isFolderNameValid -foldername $txtprojectname)
            if($r -eq $true)
            {
                ExecuteActions -aoffice $OfficeList.SelectedItem -ateam $TeamList.SelectedItem -aprojectnumber $txtprojectnumber -aprojectname $txtprojectname -aprojectdescription $ProjectDescription.Text.Trim()
            }
            else
            {
                [System.Windows.Forms.Messagebox]::Show("Project number or name invalid")
            }
        }
        else
        {
            [System.Windows.Forms.Messagebox]::Show("Following items are mandatory: `nOffice`nTeam`nProject No.")
        }
    }
)


$TabControl1 = New-Object System.Windows.Forms.TabControl
$tabPage1=New-Object System.Windows.Forms.TabPage
$tabPage1.text = "Create Project"
$tabPage1.TabIndex=0
$tabPage1.Controls.AddRange(($Lboffice, $OfficeList, $LbTeam, $TeamList, $LbProjectNumber, $ProjectNumber, $LbProjectName, $ProjectName, $LbProjectDescription, $ProjectDescription, $LbResultList,$ResultList,$BtnResult2Clipboard,$BtnResult2File, $BtnOK))

$TabControl1.Controls.Add($tabPage1)
$TabControl1.Location = New-Object System.Drawing.Point(0,0)
$TabControl1.Size=$PowerShellForms.Size
$Tabcontrol1.Add_SelectedIndexChanged(
    {
        $TabControl1.TabPages[$TabControl1.SelectedIndex].Controls.AddRange(($Lboffice, $OfficeList, $LbTeam, $TeamList))
    }
)

$PowerShellForms.Controls.Add($TabControl1)

#$TabControl1.Controls.Add()
#$PowerShellForms.Controls.AddRange(($Lboffice, $OfficeList, $LbTeam, $TeamList, $LbProjectNumber, $ProjectNumber, $LbProjectName, $ProjectName, $LbProjectDescription, $ProjectDescription, $LbResultList,$ResultList, $BtnOK))
$PowerShellForms.ShowDialog()