~~~powershell
# 2026-03-20
# @Albert Ng
# AD Security Group Manager - Version 2.9 (Enterprise Architecture Rewrite)

# =================================================================================
# 1. 架構解耦與身份驗證 (Module Load & Security Checks without runas)
# =================================================================================
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

if (-not (Get-Module -ListAvailable ActiveDirectory)) {
    [System.Windows.Forms.MessageBox]::Show("Active Directory module is required. Please install RSAT.")
    exit
}

$global:configPath = Join-Path $PSScriptRoot "config.json"
if (-not (Test-Path $global:configPath)) {
    [System.Windows.Forms.MessageBox]::Show("config.json not found! Please ensure it exists in the script directory.")
    exit
}
$config = Get-Content $global:configPath | ConvertFrom-Json

$global:modulePath = Join-Path $PSScriptRoot "AD_Security_Group_Core.psm1"
if (-not (Test-Path $global:modulePath)) {
    [System.Windows.Forms.MessageBox]::Show("AD_Security_Group_Core.psm1 not found! Please ensure it exists in the script directory.")
    exit
}
Import-Module $global:modulePath -Force

$supportGroupName = $config.SupportGroupName
$isSupportMember = $false
try {
    $currentUserSam = [Security.Principal.WindowsIdentity]::GetCurrent().Name.Split('\')[-1]
    $groupMembers = Get-ADGroupMember -Identity $supportGroupName -Recursive -ErrorAction SilentlyContinue | Select-Object -ExpandProperty SamAccountName
    if ($groupMembers -contains $currentUserSam) { $isSupportMember = $true }
}
catch { }

if (-not $isSupportMember) {
    if ([System.Windows.Forms.MessageBox]::Show("PERMISSION WARNING:`n`nYou are currently NOT a member of '$supportGroupName'.`n`nModify operations may fail due to restricted access. Continue?", "Access Check", "YesNo", "Warning") -eq "No") { exit }
}

# --- Asynchronous Job Wrapper (Runspaces + UI Synchronization) ---
function Start-AsyncJob {
    param(
        [scriptblock]$ScriptBlock,
        [hashtable]$Arguments,
        [scriptblock]$OnComplete,
        [scriptblock]$OnError
    )
    $form.Cursor = [System.Windows.Forms.Cursors]::WaitCursor
    
    $ps = [powershell]::Create()
    $null = $ps.AddScript($ScriptBlock)
    if ($Arguments) {
        $null = $ps.AddParameters($Arguments)
    }
    
    $asyncResult = $ps.BeginInvoke()
    
    $timer = New-Object System.Windows.Forms.Timer
    $timer.Interval = 200
    $timer.Add_Tick({
        if ($asyncResult.IsCompleted) {
            $timer.Stop()
            try {
                $results = $ps.EndInvoke($asyncResult)
                if ($ps.Streams.Error.Count -gt 0) {
                    throw $ps.Streams.Error[0].Exception
                }
                if ($OnComplete) { & $OnComplete $results }
            }
            catch {
                if ($OnError) { & $OnError $_ }
                else { [System.Windows.Forms.MessageBox]::Show("Async Error:`n$($_.Exception.Message)", "Error") }
            }
            finally {
                $ps.Dispose()
                $form.Cursor = [System.Windows.Forms.Cursors]::Default
            }
        }
    })
    $timer.Start()
}

function Update-Status {
    param([string]$Message)
    $statusLabel.Text = $Message
    [System.Windows.Forms.Application]::DoEvents()
}

# =================================================================================
# 2. 建立主視窗 (UI Interface Code)
# =================================================================================
$form = New-Object System.Windows.Forms.Form
$form.Text = "AD Security Group Manager (Enterprise v2.9)"
$form.Size = New-Object System.Drawing.Size(850, 1000)
$form.StartPosition = "CenterScreen"

$statusStrip = New-Object System.Windows.Forms.StatusStrip
$statusLabel = New-Object System.Windows.Forms.ToolStripStatusLabel
$statusLabel.Text = "Ready"
$statusStrip.Items.Add($statusLabel) | Out-Null
$form.Controls.Add($statusStrip)

$tabControl = New-Object System.Windows.Forms.TabControl
$tabControl.Size = New-Object System.Drawing.Size(830, 880)
$tabControl.Location = New-Object System.Drawing.Point(5, 5)
$form.Controls.Add($tabControl)

# --- [分頁 1] ACL Viewer ---
$tabACL = New-Object System.Windows.Forms.TabPage
$tabACL.Text = "ACL Viewer"
$tabControl.TabPages.Add($tabACL)

$lblPath = New-Object System.Windows.Forms.Label
$lblPath.Location = "20, 10"; $lblPath.Size = "100, 20"; $lblPath.Text = "Folder Path:"
$tabACL.Controls.Add($lblPath)
$txtPath = New-Object System.Windows.Forms.TextBox
$txtPath.Location = "20, 35"; $txtPath.Size = "790, 25"
$tabACL.Controls.Add($txtPath)
$btnCheckAcl = New-Object System.Windows.Forms.Button
$btnCheckAcl.Location = "20, 70"; $btnCheckAcl.Size = "150, 35"; $btnCheckAcl.Text = "Check Permissions"; $btnCheckAcl.BackColor = "LightGreen"
$tabACL.Controls.Add($btnCheckAcl)
$btnExportAclCsv = New-Object System.Windows.Forms.Button
$btnExportAclCsv.Location = "180, 70"; $btnExportAclCsv.Size = "150, 35"; $btnExportAclCsv.Text = "Export CSV"; $btnExportAclCsv.Enabled = $false
$tabACL.Controls.Add($btnExportAclCsv)
$dgvAcl = New-Object System.Windows.Forms.DataGridView
$dgvAcl.Location = "20, 120"; $dgvAcl.Size = "785, 360"
$dgvAcl.ReadOnly = $true; $dgvAcl.AutoSizeColumnsMode = "AllCells"; $dgvAcl.BackgroundColor = "White"; $dgvAcl.RowHeadersVisible = $false; $dgvAcl.SelectionMode = 'FullRowSelect'
$tabACL.Controls.Add($dgvAcl)

$aclContext = New-Object System.Windows.Forms.ContextMenuStrip
$miCopyGroup = $aclContext.Items.Add("Copy Group Name (no domain)")
$miCopyGroup.Add_Click({
        $selected = $dgvAcl.SelectedRows
        if ($selected.Count -gt 0) {
            $identity = $selected[0].Cells["IdentityReference"].Value
            $groupOnly = ($identity -split '\\')[-1]
            [System.Windows.Forms.Clipboard]::SetText($groupOnly)
            Update-Status "Copied group name: $groupOnly"
        }
    })
$dgvAcl.ContextMenuStrip = $aclContext

$lblAclOwner = New-Object System.Windows.Forms.Label
$lblAclOwner.Location = "20, 500"; $lblAclOwner.Size = "800, 25"; $lblAclOwner.ForeColor = "DarkBlue"
$tabACL.Controls.Add($lblAclOwner)

$btnCheckAcl.Add_Click({
    $path = $txtPath.Text.Trim()
    if ([string]::IsNullOrWhiteSpace($path) -or -not(Test-Path $path)) {
        [System.Windows.Forms.MessageBox]::Show("Please enter a valid folder path.", "Validation", "OK", "Warning"); return
    }
    Update-Status "Reading ACL for '$path' in background..."
    
    $sb = {
        param($TPath)
        $aclObj = Get-Acl -Path $TPath
        $res = @()
        foreach ($item in $aclObj.Access) {
            $res += [PSCustomObject]@{
                IdentityReference = $item.IdentityReference.ToString()
                FileSystemRights = $item.FileSystemRights.ToString()
                AccessControlType = $item.AccessControlType.ToString()
            }
        }
        return @{ Owner = $aclObj.Owner; Entries = $res; Path = $TPath }
    }
    
    Start-AsyncJob -ScriptBlock $sb -Arguments @{ TPath = $path } -OnComplete {
        param($retArgs)
        $data = $retArgs[0]
        
        $lblAclOwner.Text = "Owner: $($data.Owner)"
        $dt = New-Object System.Data.DataTable
        $dt.Columns.Add("IdentityReference") | Out-Null
        $dt.Columns.Add("FileSystemRights") | Out-Null
        $dt.Columns.Add("AccessControlType") | Out-Null
        foreach ($item in $data.Entries) {
            $row = $dt.NewRow()
            $row.IdentityReference = $item.IdentityReference
            $row.FileSystemRights = $item.FileSystemRights
            $row.AccessControlType = $item.AccessControlType
            $dt.Rows.Add($row)
        }
        $dgvAcl.DataSource = $dt
        $script:currentAclData = $dt
        $btnExportAclCsv.Enabled = ($dt.Rows.Count -gt 0)
        Update-Status "ACL loaded: $($dt.Rows.Count) entries. Owner: $($data.Owner)"
    } -OnError { Update-Status "ACL check failed."; [System.Windows.Forms.MessageBox]::Show("Access Denied or Error: $($_.Exception.Message)") }
})

# [事件] 匯出 ACL CSV
$btnExportAclCsv.Add_Click({
    if (-not $script:currentAclData) { return }
    $saveFile = New-Object System.Windows.Forms.SaveFileDialog
    $saveFile.Filter = "CSV Files (*.csv)|*.csv"; $saveFile.FileName = "ACL_Viewer_$(Get-Date -Format 'yyyyMMdd_HHmmss').csv"
    if ($saveFile.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) {
        $script:currentAclData | Export-Csv -Path $saveFile.FileName -NoTypeInformation -Encoding UTF8 -Force
        Update-Status "ACL CSV export completed: $($saveFile.FileName)"
    }
})

# --- [分頁 2] Audit Members ---
$tabView = New-Object System.Windows.Forms.TabPage
$tabView.Text = "Audit Members"
$tabControl.TabPages.Add($tabView)

$panelHint1 = New-Object System.Windows.Forms.Panel
$panelHint1.Location = "20, 10"; $panelHint1.Size = "790, 130"; $panelHint1.BackColor = "Info"
$tabView.Controls.Add($panelHint1)
$lblHint1 = New-Object System.Windows.Forms.Label
$lblHint1.Text = "FUNCTION: Review Group Membership.`n`nGUIDELINES:`n1. Enter Group Name or Email and click 'Fetch'.`n2. Use 'Export CSV' to save the current list.`n3. QUICK ACTION: Select row(s), RIGHT-CLICK, and choose 'Add selected to Modify list' to transfer users to the next tab."
$lblHint1.Dock = "Fill"; $lblHint1.Padding = "10, 10, 10, 10"; $lblHint1.Font = New-Object System.Drawing.Font("Segoe UI", 9, [System.Drawing.FontStyle]::Bold)
$panelHint1.Controls.Add($lblHint1)

$txtGroupSearch = New-Object System.Windows.Forms.TextBox
$txtGroupSearch.Location = "20, 170"; $txtGroupSearch.Width = 350
$tabView.Controls.Add($txtGroupSearch)
$btnFetch = New-Object System.Windows.Forms.Button
$btnFetch.Text = "Fetch"; $btnFetch.Location = "380, 168"; $btnFetch.Width = 80
$tabView.Controls.Add($btnFetch)
$btnExport = New-Object System.Windows.Forms.Button
$btnExport.Text = "Export CSV"; $btnExport.Location = "470, 168"; $btnExport.Width = 100; $btnExport.Enabled = $false
$tabView.Controls.Add($btnExport)
$btnClearTab1 = New-Object System.Windows.Forms.Button
$btnClearTab1.Text = "Clear All"; $btnClearTab1.Location = "580, 168"; $btnClearTab1.Width = 100
$tabView.Controls.Add($btnClearTab1)
$lblCount = New-Object System.Windows.Forms.Label
$lblCount.Text = "Total Members: 0"; $lblCount.Location = "20, 200"; $lblCount.ForeColor = "Blue"; $lblCount.AutoSize = $true
$tabView.Controls.Add($lblCount)

$lblSubGroups = New-Object System.Windows.Forms.Label
$lblSubGroups.Location = "20, 225"; $lblSubGroups.Size = "400, 18"; $lblSubGroups.Text = "Sub-Groups (nested groups inside this group):"
$lblSubGroups.Font = New-Object System.Drawing.Font("Segoe UI", 9, [System.Drawing.FontStyle]::Bold)
$tabView.Controls.Add($lblSubGroups)
$dgvSubGroups = New-Object System.Windows.Forms.DataGridView
$dgvSubGroups.Location = "20, 245"; $dgvSubGroups.Size = "785, 130"
$dgvSubGroups.ReadOnly = $true; $dgvSubGroups.AutoSizeColumnsMode = "Fill"; $dgvSubGroups.BackgroundColor = "White"; $dgvSubGroups.SelectionMode = "FullRowSelect"; $dgvSubGroups.AllowUserToAddRows = $false; $dgvSubGroups.RowHeadersVisible = $false
$tabView.Controls.Add($dgvSubGroups)

$lblMembersHeader = New-Object System.Windows.Forms.Label
$lblMembersHeader.Location = "20, 380"; $lblMembersHeader.Size = "300, 18"; $lblMembersHeader.Text = "All Members (fast lookup via LDAP filter):"
$lblMembersHeader.Font = New-Object System.Drawing.Font("Segoe UI", 9, [System.Drawing.FontStyle]::Bold)
$tabView.Controls.Add($lblMembersHeader)
$dgvMembers = New-Object System.Windows.Forms.DataGridView
$dgvMembers.Location = "20, 400"; $dgvMembers.Size = "785, 445"
$dgvMembers.ReadOnly = $true; $dgvMembers.AutoSizeColumnsMode = "Fill"; $dgvMembers.SelectionMode = "FullRowSelect"; $dgvMembers.AllowUserToAddRows = $false
$tabView.Controls.Add($dgvMembers)

# [事件] 背景抓取 AD 資料
$btnFetch.Add_Click({
    $target = $txtGroupSearch.Text.Trim()
    if ([string]::IsNullOrWhiteSpace($target)) { [System.Windows.Forms.MessageBox]::Show("Empty Group Name."); return }
    Update-Status "Fetching members for '$target' asynchronously..."
    
    $sb = {
        param($TargetName, $ModPath)
        Import-Module $ModPath -Force
        $group = Resolve-ADObjectFast -SearchValue $TargetName -IsGroup
        $subGroups = Get-ADGroupSubGroups -Group $group
        
        $subGroupData = @()
        foreach ($sg in $subGroups) {
            $count = (Get-ADGroupMember -Identity $sg -Recursive -ErrorAction SilentlyContinue | Where-Object { $_.objectClass -eq 'user' }).Count
            $subGroupData += [PSCustomObject]@{ Name = $sg.Name; Count = $count }
        }
        
        $members = Get-ADGroupMemberFast -Group $group
        return @{ Sub = $subGroupData; Mem = $members; GroupName = $group.Name }
    }
    
    Start-AsyncJob -ScriptBlock $sb -Arguments @{ TargetName = $target; ModPath = $global:modulePath } -OnComplete {
        param($res)
        $data = $res[0]
        
        $dtSub = New-Object System.Data.DataTable
        $dtSub.Columns.Add("Sub-Group Name") | Out-Null
        $dtSub.Columns.Add("Members (recursive)") | Out-Null
        foreach ($d in $data.Sub) {
            $row = $dtSub.NewRow()
            $row."Sub-Group Name" = $d.Name
            $row."Members (recursive)" = $d.Count
            $dtSub.Rows.Add($row)
        }
        $dgvSubGroups.DataSource = $dtSub
        
        $dtMem = New-Object System.Data.DataTable
        $dtMem.Columns.Add("DisplayName") | Out-Null
        $dtMem.Columns.Add("SamAccountName") | Out-Null
        $dtMem.Columns.Add("mail") | Out-Null
        $dtMem.Columns.Add("Department") | Out-Null
        $dtMem.Columns.Add("Title") | Out-Null
        foreach ($m in $data.Mem) {
            $row = $dtMem.NewRow()
            $row.DisplayName = $m.DisplayName
            $row.SamAccountName = $m.SamAccountName
            $row.mail = $m.mail
            $row.Department = $m.Department
            $row.Title = $m.Title
            $dtMem.Rows.Add($row)
        }
        $dgvMembers.DataSource = $dtMem
        $lblCount.Text = "Sub-Groups: $($dtSub.Rows.Count) | Total Members: $($data.Mem.Count)"
        $btnExport.Enabled = ($dtMem.Rows.Count -gt 0)
        $script:currentData = $data.Mem
        Update-Status "Loaded $($dtSub.Rows.Count) sub-group(s) and $($dtMem.Rows.Count) member(s) from '$($data.GroupName)'."
    } -OnError { Update-Status "Fetch failed." ; [System.Windows.Forms.MessageBox]::Show("Failed to load targets.`n`n$($_.Exception.Message)", "Error") }
})

$btnExport.Add_Click({
    if (-not $script:currentData) { return }
    $saveFile = New-Object System.Windows.Forms.SaveFileDialog
    $saveFile.Filter = "CSV Files (*.csv)|*.csv"; $saveFile.FileName = "GroupMembers_$(Get-Date -Format 'yyyyMMdd_HHmmss').csv"
    if ($saveFile.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) {
        $script:currentData | Export-Csv -Path $saveFile.FileName -NoTypeInformation -Encoding UTF8 -Force
        Update-Status "Exported to $($saveFile.FileName)"
    }
})

$contextMenu = New-Object System.Windows.Forms.ContextMenuStrip
$menuItemAdd = $contextMenu.Items.Add("Add selected to Modify list")
$menuItemAdd.Add_Click({
    if ($dgvMembers.SelectedRows.Count -gt 0) {
        foreach ($row in $dgvMembers.SelectedRows) {
            $sam = $row.Cells["SamAccountName"].Value.ToString()
            if ($sam) { $null = $dgvInput.Rows.Add($sam) }
        }
        $tabControl.SelectedTab = $tabUpdate
        Update-Status "Transferred $($dgvMembers.SelectedRows.Count) user(s) to Bulk Updates tab."
    }
})
$dgvMembers.ContextMenuStrip = $contextMenu

# --- [分頁 3] Bulk Updates ---
$tabUpdate = New-Object System.Windows.Forms.TabPage
$tabUpdate.Text = "Bulk Updates"
$tabControl.TabPages.Add($tabUpdate)

$panelHint2 = New-Object System.Windows.Forms.Panel
$panelHint2.Location = "20, 10"; $panelHint2.Size = "790, 150"; $panelHint2.BackColor = "Info"
$tabUpdate.Controls.Add($panelHint2)
$lblHint2 = New-Object System.Windows.Forms.Label
$lblHint2.Text = "FUNCTION: Bulk Membership Management.`n`nGUIDELINES:`n1. Enter the 'Target Security Group'.`n2. Populate identifiers (Email/SAM) via Import or Right-Click from the Audit tab.`n3. Select 'Bulk ADD' or 'Bulk REMOVE'.`n4. Structure Logs will be saved accurately."
$lblHint2.Dock = "Fill"; $lblHint2.Padding = "10, 10, 10, 10"; $lblHint2.Font = New-Object System.Drawing.Font("Segoe UI", 9, [System.Drawing.FontStyle]::Bold)
$panelHint2.Controls.Add($lblHint2)

$txtTargetGroup = New-Object System.Windows.Forms.TextBox
$txtTargetGroup.Location = "20, 195"; $txtTargetGroup.Width = 400
$tabUpdate.Controls.Add($txtTargetGroup)
$btnImportFile = New-Object System.Windows.Forms.Button
$btnImportFile.Text = "Upload CSV/TXT"; $btnImportFile.Location = "430, 193"; $btnImportFile.Width = 130
$tabUpdate.Controls.Add($btnImportFile)

$btnImportFile.Add_Click({
    $openFile = New-Object System.Windows.Forms.OpenFileDialog
    $openFile.Filter = "CSV/TXT Files (*.csv;*.txt)|*.csv;*.txt"
    if ($openFile.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) {
        $lines = Get-Content $openFile.FileName | Where-Object { $_.Trim() -ne "" }
        foreach ($line in $lines) { $dgvInput.Rows.Add($line.Trim()) | Out-Null }
        Update-Status "Imported $($lines.Count) identifier(s) from file."
    }
})

$dgvInput = New-Object System.Windows.Forms.DataGridView
$dgvInput.Location = "20, 230"; $dgvInput.Size = "785, 220"
$col1 = New-Object System.Windows.Forms.DataGridViewTextBoxColumn
$col1.HeaderText = "User Identifier (Email or SAM)"; $col1.Name = "colIdentifier"; $col1.Width = 700
$dgvInput.Columns.Add($col1) | Out-Null
$tabUpdate.Controls.Add($dgvInput)

$btnAdd = New-Object System.Windows.Forms.Button
$btnAdd.Text = "Bulk ADD"; $btnAdd.Location = "20, 465"; $btnAdd.Width = 120; $btnAdd.BackColor = "LightGreen"
$tabUpdate.Controls.Add($btnAdd)
$btnRemove = New-Object System.Windows.Forms.Button
$btnRemove.Text = "Bulk REMOVE"; $btnRemove.Location = "150, 465"; $btnRemove.Width = 120; $btnRemove.BackColor = "LightCoral"
$tabUpdate.Controls.Add($btnRemove)
$btnClearTab2 = New-Object System.Windows.Forms.Button
$btnClearTab2.Text = "Clear List"; $btnClearTab2.Location = "685, 465"; $btnClearTab2.Width = 120
$tabUpdate.Controls.Add($btnClearTab2)

$txtUpdateLog = New-Object System.Windows.Forms.TextBox
$txtUpdateLog.Location = "20, 500"; $txtUpdateLog.Size = "785, 330"; $txtUpdateLog.Multiline = $true; $txtUpdateLog.ReadOnly = $true; $txtUpdateLog.ScrollBars = "Vertical"
$tabUpdate.Controls.Add($txtUpdateLog)

$ProcessGrid = {
    param($Action)
    $groupName = $txtTargetGroup.Text.Trim()
    $userList = New-Object System.Collections.Generic.List[string]
    foreach ($row in $dgvInput.Rows) { if ($row.Cells["colIdentifier"].Value) { $userList.Add($row.Cells["colIdentifier"].Value.ToString().Trim()) } }
    $users = $userList | Select-Object -Unique
    if ([string]::IsNullOrWhiteSpace($groupName) -or $users.Count -eq 0) { [System.Windows.Forms.MessageBox]::Show("Provide Target Group and Users.", "Validation", "OK", "Warning"); return }
    
    if ([System.Windows.Forms.MessageBox]::Show("You are about to $($Action.ToUpper()) $($users.Count) user(s) to/from group:`n`n$groupName`n`nProceed?", "Confirm", "YesNo", "Question") -eq "No") { return }
    
    Update-Status "Executing Bulk $Action asynchronously..."
    
    $sb = {
        param($TargetName, $UserArray, $OpMode, $ModPath)
        Import-Module $ModPath -Force
        return Invoke-BulkUpdateMember -TargetGroup $TargetName -Users $UserArray -Action $OpMode
    }
    
    Start-AsyncJob -ScriptBlock $sb -Arguments @{ TargetName = $groupName; UserArray = @($users); OpMode = $Action; ModPath = $global:modulePath } -OnComplete {
        param($resArgs)
        $output = $resArgs[0] # Note: EndInvoke wraps multiple objects to array, usually. If it returns an enumerator, powershell unrolls it.
        $successCount = 0; $errorCount = 0
        if ($output.GetType().IsArray) {
            foreach ($i in $output) {
                if ($i.Success) { $successCount++ } else { $errorCount++ }
                $txtUpdateLog.AppendText("`r`n$($i.Status)")
            }
        } elseif ($output) {
            if ($output.Success) { $successCount++ } else { $errorCount++ }
            $txtUpdateLog.AppendText("`r`n$($output.Status)")
        }
        $txtUpdateLog.ScrollToCaret()
        [System.Windows.Forms.MessageBox]::Show("Bulk $Action complete.`n`nSuccess: $successCount | Errors: $errorCount`nDetailed output in JSON structural logs.", "Information")
        Update-Status "Completed Bulk $Action. Success: $successCount, Error: $errorCount."
    } -OnError { Update-Status "Bulk Add Error."; [System.Windows.Forms.MessageBox]::Show("Operation error: $($_.Exception.Message)", "Error") }
}

$btnAdd.Add_Click({ &$ProcessGrid "Add" })
$btnRemove.Add_Click({ &$ProcessGrid "Remove" })

# --- [分頁 4] Access Checker ---
$tabAccessChk = New-Object System.Windows.Forms.TabPage
$tabAccessChk.Text = "Access Checker"
$tabControl.TabPages.Add($tabAccessChk)

$panelHint4 = New-Object System.Windows.Forms.Panel
$panelHint4.Location = "20, 10"; $panelHint4.Size = "790, 110"; $panelHint4.BackColor = "Info"
$tabAccessChk.Controls.Add($panelHint4)
$lblHint4 = New-Object System.Windows.Forms.Label
$lblHint4.Text = "FUNCTION: Check Individual Access Rights.`n`nGUIDELINES:`n1. Enter Folder path.`n2. Enter User.`n3. Performs effective permission analysis via ADSI."
$lblHint4.Dock = "Fill"; $lblHint4.Padding = "10, 10, 10, 10"; $lblHint4.Font = New-Object System.Drawing.Font("Segoe UI", 9, [System.Drawing.FontStyle]::Bold)
$panelHint4.Controls.Add($lblHint4)

$lblAccessPath = New-Object System.Windows.Forms.Label
$lblAccessPath.Location = "20, 130"; $lblAccessPath.Size = "100, 20"; $lblAccessPath.Text = "Folder Path:"
$tabAccessChk.Controls.Add($lblAccessPath)
$txtAccessPath = New-Object System.Windows.Forms.TextBox
$txtAccessPath.Location = "20, 155"; $txtAccessPath.Size = "790, 25"
$tabAccessChk.Controls.Add($txtAccessPath)
$lblAccessUser = New-Object System.Windows.Forms.Label
$lblAccessUser.Location = "20, 195"; $lblAccessUser.Size = "150, 20"; $lblAccessUser.Text = "User (Email or SAM):"
$tabAccessChk.Controls.Add($lblAccessUser)
$txtAccessUser = New-Object System.Windows.Forms.TextBox
$txtAccessUser.Location = "20, 220"; $txtAccessUser.Size = "400, 25"
$tabAccessChk.Controls.Add($txtAccessUser)

$btnCheckAccess = New-Object System.Windows.Forms.Button
$btnCheckAccess.Location = "430, 218"; $btnCheckAccess.Size = "150, 30"; $btnCheckAccess.Text = "Check Access"; $btnCheckAccess.BackColor = "LightGreen"
$tabAccessChk.Controls.Add($btnCheckAccess)
$btnClearTab4 = New-Object System.Windows.Forms.Button
$btnClearTab4.Location = "590, 218"; $btnClearTab4.Size = "100, 30"; $btnClearTab4.Text = "Clear"
$tabAccessChk.Controls.Add($btnClearTab4)

$lblAccessInfo = New-Object System.Windows.Forms.Label
$lblAccessInfo.Location = "20, 260"; $lblAccessInfo.Size = "790, 20"; $lblAccessInfo.ForeColor = "DarkBlue"; $lblAccessInfo.AutoSize = $true
$tabAccessChk.Controls.Add($lblAccessInfo)

$lblMatchedGroups = New-Object System.Windows.Forms.Label
$lblMatchedGroups.Location = "20, 285"; $lblMatchedGroups.Size = "400, 18"; $lblMatchedGroups.Text = "Matched Groups (ACL Group → User Membership Path):"
$lblMatchedGroups.Font = New-Object System.Drawing.Font("Segoe UI", 9, [System.Drawing.FontStyle]::Bold)
$tabAccessChk.Controls.Add($lblMatchedGroups)
$dgvMatchedGroups = New-Object System.Windows.Forms.DataGridView
$dgvMatchedGroups.Location = "20, 305"; $dgvMatchedGroups.Size = "785, 130"; $dgvMatchedGroups.BackColor = "White"
$dgvMatchedGroups.ReadOnly = $true; $dgvMatchedGroups.AutoSizeColumnsMode = "Fill"; $dgvMatchedGroups.SelectionMode = "FullRowSelect"; $dgvMatchedGroups.AllowUserToAddRows = $false; $dgvMatchedGroups.RowHeadersVisible = $false
$tabAccessChk.Controls.Add($dgvMatchedGroups)

$lblPermHeader = New-Object System.Windows.Forms.Label
$lblPermHeader.Location = "20, 440"; $lblPermHeader.Size = "300, 18"; $lblPermHeader.Text = "Effective Permissions:"
$lblPermHeader.Font = New-Object System.Drawing.Font("Segoe UI", 9, [System.Drawing.FontStyle]::Bold)
$tabAccessChk.Controls.Add($lblPermHeader)
$dgvAccess = New-Object System.Windows.Forms.DataGridView
$dgvAccess.Location = "20, 460"; $dgvAccess.Size = "785, 375"
$dgvAccess.ReadOnly = $true; $dgvAccess.AutoSizeColumnsMode = "Fill"; $dgvAccess.BackgroundColor = "White"; $dgvAccess.SelectionMode = "FullRowSelect"; $dgvAccess.AllowUserToAddRows = $false; $dgvAccess.RowHeadersVisible = $false
$tabAccessChk.Controls.Add($dgvAccess)

$btnCheckAccess.Add_Click({
    $path = $txtAccessPath.Text.Trim(); $userSearch = $txtAccessUser.Text.Trim()
    if ([string]::IsNullOrWhiteSpace($path) -or [string]::IsNullOrWhiteSpace($userSearch)) { return }
    if (-not (Test-Path $path)) { [System.Windows.Forms.MessageBox]::Show("Invalid Path.", "Error"); return }
    Update-Status "Checking access iteratively in background..."
    
    $sb = {
        param($PPath, $Un, $ModPath)
        Import-Module $ModPath -Force
        $adUser = Resolve-ADObjectFast -SearchValue $Un
        $userGroups = Get-ADUserEffectiveGroups -ADUser $adUser
        
        $aclObj = Get-Acl -Path $PPath
        $dtMatches = @()
        $dtAcl = @()
        
        $matchedGroupNames = @()
        foreach ($ace in $aclObj.Access) {
            $identity = ($ace.IdentityReference.Value -split '\\')[-1]
            if ($identity -eq $adUser.SamAccountName) {
                $dtAcl += [PSCustomObject]@{ IR = $ace.IdentityReference.Value; FSR = $ace.FileSystemRights.ToString(); ACT = $ace.AccessControlType.ToString(); Inh = $ace.IsInherited.ToString(); Type = "Direct" }
            } elseif ($identity -in $userGroups) {
                $dtAcl += [PSCustomObject]@{ IR = $ace.IdentityReference.Value; FSR = $ace.FileSystemRights.ToString(); ACT = $ace.AccessControlType.ToString(); Inh = $ace.IsInherited.ToString(); Type = "Via Group" }
                if ($identity -notin $matchedGroupNames) {
                    $matchedGroupNames += $identity
                    $dtMatches += [PSCustomObject]@{ AclGroup = $identity; Membership = "Verified via ADSI tokenGroups (Nested or Direct)" }
                }
            }
        }
        
        return @{ ADUser = $adUser; GroupsCount = $userGroups.Count; Matches = $dtMatches; AclEntries = $dtAcl }
    }
    
    Start-AsyncJob -ScriptBlock $sb -Arguments @{ PPath = $path; Un = $userSearch; ModPath = $global:modulePath } -OnComplete {
        param($resArgs)
        $data = $resArgs[0]
        
        $dtGroup = New-Object System.Data.DataTable
        $dtGroup.Columns.Add("ACL Group") | Out-Null
        $dtGroup.Columns.Add("Membership") | Out-Null
        foreach ($r in $data.Matches) { $row = $dtGroup.NewRow(); $row."ACL Group" = $r.AclGroup; $row."Membership" = $r.Membership; $dtGroup.Rows.Add($row) }
        $dgvMatchedGroups.DataSource = $dtGroup
        
        $dtApp = New-Object System.Data.DataTable
        $dtApp.Columns.Add("IdentityReference") | Out-Null; $dtApp.Columns.Add("FileSystemRights") | Out-Null; $dtApp.Columns.Add("AccessControlType") | Out-Null; $dtApp.Columns.Add("IsInherited") | Out-Null; $dtApp.Columns.Add("AccessType") | Out-Null
        foreach ($r in $data.AclEntries) {
            $row = $dtApp.NewRow(); $row.IdentityReference = $r.IR; $row.FileSystemRights = $r.FSR; $row.AccessControlType = $r.ACT; $row.IsInherited = $r.Inh; $row.AccessType = $r.Type; $dtApp.Rows.Add($row)
        }
        $dgvAccess.DataSource = $dtApp
        
        $lblAccessInfo.Text = "User: $($data.ADUser.SamAccountName) | Total Deep Groups: $($data.GroupsCount) | Matched Groups: $($dtGroup.Rows.Count) | Effective ACLs: $($dtApp.Rows.Count)"
        Update-Status "Completed access check for $($data.ADUser.SamAccountName)"
    } -OnError { Update-Status "Check Failed"; [System.Windows.Forms.MessageBox]::Show("Error: $($_.Exception.Message)") }
})

# 清除所有分頁狀態
$btnClearTab1.Add_Click({ $txtGroupSearch.Text = ""; $dgvMembers.DataSource = $null; $dgvSubGroups.DataSource = $null; $lblCount.Text = "Sub-Groups: 0 | Total Members: 0"; $btnExport.Enabled = $false; Update-Status "Audit tab cleared." })
$btnClearTab2.Add_Click({ $txtTargetGroup.Text = ""; $dgvInput.Rows.Clear(); $txtUpdateLog.Clear(); Update-Status "Bulk Updates tab cleared." })
$btnClearTab4.Add_Click({ $txtAccessPath.Text = ""; $txtAccessUser.Text = ""; $dgvAccess.DataSource = $null; $dgvMatchedGroups.DataSource = $null; $lblAccessInfo.Text = ""; Update-Status "Access Checker tab cleared." })

# 全域結束按鈕
$btnExit = New-Object System.Windows.Forms.Button
$btnExit.Text = "EXIT PROGRAM"
$btnExit.Location = New-Object System.Drawing.Point(30, 900)
$btnExit.Size = New-Object System.Drawing.Size(770, 45)
$btnExit.BackColor = "Gainsboro"
$btnExit.Font = New-Object System.Drawing.Font("Segoe UI", 10, [System.Drawing.FontStyle]::Bold)
$btnExit.Add_Click({
        if ([System.Windows.Forms.MessageBox]::Show("Are you sure you want to exit?", "Exit Confirmation", "YesNo", "Question") -eq "Yes") {
            $form.Close()
        }
    })
$form.Controls.Add($btnExit)

# 顯示主視窗
$form.ShowDialog()
~~~