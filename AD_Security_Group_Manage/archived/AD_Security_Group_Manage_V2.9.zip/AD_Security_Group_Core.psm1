# AD_Security_Group_Core.psm1
# Enterprise PowerShell Module for AD Management
# Separates Business Logic from UI

Import-Module ActiveDirectory -ErrorAction SilentlyContinue

function Write-ADManagerLog {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)] [string]$Action,
        [Parameter(Mandatory=$true)] [string]$Target,
        [Parameter(Mandatory=$true)] [string]$Status,
        [string]$Details = "",
        [string]$LogDir = ".\Logs"
    )
    if (-not (Test-Path $LogDir)) { New-Item -ItemType Directory -Path $LogDir -Force | Out-Null }
    
    $timestamp = (Get-Date).ToString("yyyy-MM-ddTHH:mm:ssK")
    $user = [Security.Principal.WindowsIdentity]::GetCurrent().Name
    
    $logEntry = [ordered]@{
        Timestamp = $timestamp
        User      = $user
        Action    = $Action
        Target    = $Target
        Status    = $Status
        Details   = $Details
    }
    
    $json = $logEntry | ConvertTo-Json -Compress
    $logFile = Join-Path $LogDir "ADManager_$(Get-Date -Format 'yyyyMMdd').log"
    Add-Content -Path $logFile -Value $json -Encoding UTF8 -ErrorAction SilentlyContinue
}

function Resolve-ADObjectFast {
    [CmdletBinding()]
    param([string]$SearchValue, [switch]$IsGroup)
    $val = $SearchValue.Trim()
    if ($IsGroup) {
        Get-ADGroup -Filter { Name -eq $val -or mail -eq $val } -ErrorAction Stop
    } else {
        Get-ADUser -Filter { mail -eq $val -or SamAccountName -eq $val } -ErrorAction Stop
    }
}

function Get-ADGroupMemberFast {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)]
        [Microsoft.ActiveDirectory.Management.ADGroup]$Group
    )
    $filter = "(memberOf:1.2.840.113556.1.4.1941:=$($Group.DistinguishedName))"
    $users = Get-ADUser -LDAPFilter $filter -Properties mail, DisplayName, Department, Title -ErrorAction SilentlyContinue |
             Select-Object DisplayName, SamAccountName, mail, Department, Title
    return $users
}

function Get-ADUserEffectiveGroups {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)]
        [Microsoft.ActiveDirectory.Management.ADUser]$ADUser
    )
    $userGroups = @()
    try {
        $userDN = $ADUser.DistinguishedName
        $userEntry = [ADSI]"LDAP://$userDN"
        $userEntry.RefreshCache("tokenGroups")
        $sids = $userEntry.Properties["tokenGroups"]
        foreach ($sidBytes in $sids) {
            $sid = New-Object System.Security.Principal.SecurityIdentifier($sidBytes, 0)
            try { $userGroups += (Get-ADGroup $sid -ErrorAction SilentlyContinue).Name } catch {}
        }
    }
    catch {
        # Fallback
        try {
            $userGroups = Get-ADPrincipalGroupMembership $ADUser -ErrorAction SilentlyContinue | Select-Object -ExpandProperty Name
        } catch {
            $userObj = Get-ADUser $ADUser -Properties MemberOf
            $userGroups = $userObj.MemberOf | ForEach-Object { (Get-ADGroup $_ -ErrorAction SilentlyContinue).Name }
        }
    }
    return $userGroups | Where-Object { $_ }
}

function Get-ADGroupSubGroups {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)]
        [Microsoft.ActiveDirectory.Management.ADGroup]$Group
    )
    return Get-ADGroupMember -Identity $Group -ErrorAction SilentlyContinue | Where-Object { $_.objectClass -eq 'group' }
}

function Invoke-BulkUpdateMember {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)] [string]$TargetGroup,
        [Parameter(Mandatory=$true)] [string[]]$Users,
        [Parameter(Mandatory=$true)] [string]$Action,
        [string]$LogDir = ".\Logs"
    )
    $results = @()
    try {
        $group = Resolve-ADObjectFast -SearchValue $TargetGroup -IsGroup
        foreach ($u in $Users) {
            try {
                $adUser = Resolve-ADObjectFast -SearchValue $u
                if ($Action -eq "Add") {
                    Add-ADGroupMember $group $adUser -ErrorAction Stop
                    $status = "[SUCCESS] Added: $u"
                    Write-ADManagerLog -Action "BulkAdd" -Target $TargetGroup -Status "Success" -Details "Added user $u" -LogDir $LogDir
                } else {
                    Remove-ADGroupMember $group $adUser -Confirm:$false -ErrorAction Stop
                    $status = "[SUCCESS] Removed: $u"
                    Write-ADManagerLog -Action "BulkRemove" -Target $TargetGroup -Status "Success" -Details "Removed user $u" -LogDir $LogDir
                }
                $results += [PSCustomObject]@{ User = $u; Status = $status; Success = $true }
            } catch {
                $status = "[ERROR] $u : $($_.Exception.Message)"
                Write-ADManagerLog -Action "Bulk$Action" -Target $TargetGroup -Status "Error" -Details "Failed for $u" -LogDir $LogDir
                $results += [PSCustomObject]@{ User = $u; Status = $status; Success = $false }
            }
        }
    } catch {
        throw "Target Group resolution failed: $($_.Exception.Message)"
    }
    return $results
}

Export-ModuleMember -Function Write-ADManagerLog, Resolve-ADObjectFast, Get-ADGroupMemberFast, Get-ADUserEffectiveGroups, Get-ADGroupSubGroups, Invoke-BulkUpdateMember
